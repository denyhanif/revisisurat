/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : MySQL
 Source Server Version : 80019
 Source Host           : localhost:3306
 Source Schema         : surat

 Target Server Type    : MySQL
 Target Server Version : 80019
 File Encoding         : 65001

 Date: 23/11/2020 22:58:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for data_kelahiran
-- ----------------------------
DROP TABLE IF EXISTS `data_kelahiran`;
CREATE TABLE `data_kelahiran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_kk` varchar(255) DEFAULT NULL,
  `nama_kk` varchar(255) DEFAULT NULL,
  `nik` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `jk` enum('L','P') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tmpt_lahiran` varchar(255) DEFAULT NULL,
  `tmpt_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` varchar(255) DEFAULT NULL,
  `jenis_kelahiran` varchar(255) DEFAULT NULL,
  `kelahiran_ke` varchar(255) DEFAULT NULL,
  `penolong_lahir` varchar(255) DEFAULT NULL,
  `berat` varchar(255) DEFAULT NULL,
  `panjang` varchar(255) DEFAULT NULL,
  `ibu_nik` varchar(255) DEFAULT NULL,
  `ibu_nama` varchar(255) DEFAULT NULL,
  `ibu_tmpt_lahir` varchar(255) DEFAULT NULL,
  `ibu_tgl_lahir` varchar(255) DEFAULT NULL,
  `ibu_pekerjaan` varchar(255) DEFAULT NULL,
  `ibu_alamat` varchar(255) DEFAULT NULL,
  `ibu_kewarganegaraan` varchar(255) DEFAULT NULL,
  `ibu_tgl_kawin` varchar(255) DEFAULT NULL,
  `ayah_nik` varchar(255) DEFAULT NULL,
  `ayah_nama` varchar(255) DEFAULT NULL,
  `ayah_tmpt_lahir` varchar(255) DEFAULT NULL,
  `ayah_tgl_lahir` varchar(255) DEFAULT NULL,
  `ayah_pekerjaan` varchar(255) DEFAULT NULL,
  `ayah_alamat` varchar(255) DEFAULT NULL,
  `ayah_kewarganegaraan` varchar(255) DEFAULT NULL,
  `pelapor_nik` varchar(255) DEFAULT NULL,
  `pelapor_nama` varchar(255) DEFAULT NULL,
  `pelapor_tmp_lahir` varchar(255) DEFAULT NULL,
  `pelapor_tgl_lahir` varchar(255) DEFAULT NULL,
  `pelapor_umur` varchar(255) DEFAULT NULL,
  `pelapor_kerja` varchar(255) DEFAULT NULL,
  `pelapor_alamat` varchar(255) DEFAULT NULL,
  `tgl_lapor` varchar(255) DEFAULT NULL,
  `saksi_nik` varchar(255) DEFAULT NULL,
  `saksi_nama` varchar(255) DEFAULT NULL,
  `saksi_umur` varchar(255) DEFAULT NULL,
  `saksi_alamat` varchar(255) DEFAULT NULL,
  `saksi_2_nik` varchar(255) DEFAULT NULL,
  `saksi_2_nama` varchar(255) DEFAULT NULL,
  `saksi_2_umur` varchar(255) DEFAULT NULL,
  `saksi_2_alamat` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of data_kelahiran
-- ----------------------------
BEGIN;
INSERT INTO `data_kelahiran` VALUES (2, '65454544', 'wakyu', NULL, 'bayi', 'L', 'RS', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdas', '12', '50', 'asdasdas', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', '12', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', '12', 'asdasd', 'asdasd', 'asdasd', '12', 'asdasd');
COMMIT;

-- ----------------------------
-- Table structure for data_kematian
-- ----------------------------
DROP TABLE IF EXISTS `data_kematian`;
CREATE TABLE `data_kematian` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nik` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `jk` varchar(255) DEFAULT NULL,
  `tmpt_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `agama` varchar(255) DEFAULT NULL,
  `pekerjaan` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `anak_ke` varchar(255) DEFAULT NULL,
  `meninggal_tgl` varchar(255) DEFAULT NULL,
  `tmpt_meninggal` varchar(255) DEFAULT NULL,
  `sebab` varchar(255) DEFAULT NULL,
  `tmpt_kematian` varchar(255) DEFAULT NULL,
  `menerangkan` varchar(255) DEFAULT NULL,
  `ibu_nik` varchar(255) DEFAULT NULL,
  `ibu_nama` varchar(255) DEFAULT NULL,
  `ibu_tmpt_lahir` varchar(255) DEFAULT NULL,
  `ibu_pekerjaan` varchar(255) DEFAULT NULL,
  `ibu_alamat` varchar(255) DEFAULT NULL,
  `ibu_kewarganegaraan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ayah_nik` varchar(255) DEFAULT NULL,
  `ayah_nama` varchar(255) DEFAULT NULL,
  `ayah_tmpt_lahir` varchar(255) DEFAULT NULL,
  `ayah_pekerjaan` varchar(255) DEFAULT NULL,
  `ayah_alamat` varchar(255) DEFAULT NULL,
  `ayah_kewarganegaraan` varchar(255) DEFAULT NULL,
  `pelapor_nik` varchar(255) DEFAULT NULL,
  `pelapor_nama` varchar(255) DEFAULT NULL,
  `pelapor_tmp_lahir` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pelapor_tgl_lahir` varchar(255) DEFAULT NULL,
  `pelapor_umur` varchar(255) DEFAULT NULL,
  `pelapor_kerja` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pelapor_alamat` varchar(255) DEFAULT NULL,
  `tgl_lapor` varchar(255) DEFAULT NULL,
  `saksi_nik` varchar(255) DEFAULT NULL,
  `saksi_nama` varchar(255) DEFAULT NULL,
  `saksi_umur` varchar(255) DEFAULT NULL,
  `saksi_alamat` varchar(255) DEFAULT NULL,
  `no_kk` varchar(255) DEFAULT NULL,
  `nama_kk` varchar(255) DEFAULT NULL,
  `ayah_tgl_lahir` varchar(255) DEFAULT NULL,
  `ibu_tgl_lahir` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of data_kematian
-- ----------------------------
BEGIN;
INSERT INTO `data_kematian` VALUES (1, '123123', 'jenasah', 'katholik', 'yogya', '14121994', NULL, 'buruh', 'asdasd', '1', '3', '33', '3', '2131', '1231', NULL, 'asdad', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'sadas', 'asdasd', 'asdasd', 'asdasd', 'asdasd', '12', 'adasda', 'asdasd', 'sdasdasd', 'asdasd', 'sdasdasd', '2323', 'asadsadasd', '123123123', 'aku juga', 'asdasd', 'asdad');
COMMIT;

-- ----------------------------
-- Table structure for data_pengajuans
-- ----------------------------
DROP TABLE IF EXISTS `data_pengajuans`;
CREATE TABLE `data_pengajuans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori_surat_id` bigint unsigned NOT NULL,
  `warga_id` bigint unsigned DEFAULT NULL,
  `nama_pemesan` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `jenis_kelamin` enum('pria','wanita') CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `tempat_lahir` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `tanggal_lahir` varchar(0) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nik` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `alamat` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `pekerjaan` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_perkawinan` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `agama` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `berkas` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  `data` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of data_pengajuans
-- ----------------------------
BEGIN;
INSERT INTO `data_pengajuans` VALUES (1, 1, NULL, 'warga1kolomanak', 'pria', NULL, NULL, NULL, NULL, NULL, 'Kawin', 'Islam', NULL, '2020-11-12 11:41:52', '2020-11-12 11:42:24', '{\"nomer_kartu_keluarga\":\"122\",\"nama_kepala_keluarga\":\"john lennnon\",\"nama_lengkap_bayi\":\"nama bayi\",\"jenis_kelamin_bayi\":\"perempuan\",\"tempat_dilahirkan\":\"rumahsakit\",\"tempat_kelahiran\":\"jakarta\",\"hari_dilahirkan\":\"selasa\",\"tanggal_lahir\":\"12\\/20\\/1010\",\"jam_kelahiran\":\"3\",\"jenis_kelahiran\":\"tunggal\",\"kelahiran_ke\":\"Satu\",\"penolong_kelahiran\":\"Suster\",\"berat_bayi\":\"4\",\"panjang_bayi\":\"2\"}');
INSERT INTO `data_pengajuans` VALUES (3, 1, NULL, 'warga1allss', 'pria', NULL, NULL, NULL, NULL, NULL, 'Kawin', 'Islam', NULL, '2020-11-12 12:27:28', '2020-11-22 14:48:13', '{\"nomer_kartu_keluarga\":\"122\",\"nama_kepala_keluarga\":\"bapak1\",\"nama_lengkap_bayi\":\"nama bayi\",\"jenis_kelamin_bayi\":\"laki\",\"tempat_dilahirkan\":\"rumahsakit\",\"tempat_kelahiran\":\"jogja\",\"hari_dilahirkan\":\"selasa\",\"tanggal_lahir\":\"2020-11-09\",\"jam_kelahiran\":\"3\",\"jenis_kelahiran\":\"Tunggal\",\"kelahiran_ke\":\"dua\",\"penolong_kelahiran\":\"Suster\",\"berat_bayi\":\"4\",\"panjang_bayi\":\"2\",\"nik_ibu\":\"11\",\"nama_lengkap_ibu\":\"wati ibu\",\"tempat_tangga_lahir_ibu\":\"jogja , 2\\/2\\/2020\",\"pekerjaan_ibu\":\"pedagang\",\"alamat_lengkap_ibu\":\"jakal km rt3 rw2\",\"kewarga_negaraan_ibu\":\"indonesia\",\"tanggal_pernikahan\":\"2020-11-27\",\"nik_ayah\":\"23213133413\",\"nama_lengkap_ayah\":\"budi\",\"tempat_tanggal_lahir_ayah\":\"jogja 23\\/12\\/12\",\"umur_ayah\":\"22\",\"pakerjaan_ayah\":\"burug\",\"alamat_ayah\":\"jl kaliurang km 17\",\"kewarganegaraan_ayah\":\"a\",\"nik_pelapor\":\"121\",\"nama_lengkap_pelapor\":\"ff\",\"tempat_tanggal_lahir_pelapor\":\"selman 23\\/23\\/23\",\"umur_pelapor\":\"12\",\"pekerjaan_pelapor\":\"pedagang\",\"alamat_pelapor\":\"jl kaliurabf km 14\",\"tanggal_lapor\":\"2020-11-26\",\"nik_saksi1\":\"121\",\"nama_lengkap_saksi1\":\"dddd\",\"umur_saksi1\":\"12\",\"alamat_saksi1\":\"jl kaliurang\",\"nik_saksi2\":\"1232132144\",\"nama_lengkap_saksi2\":\"df\",\"umur_saksi2\":\"2\",\"alamat_saksi2\":\"jl magelang\"}');
INSERT INTO `data_pengajuans` VALUES (4, 2, NULL, 'warga1', 'pria', NULL, NULL, NULL, NULL, NULL, 'Kawin', 'Islam', NULL, '2020-11-12 13:34:05', '2020-11-12 13:34:59', '{\"nama_kepa_keluarga\":\"yuda\",\"nomer_kartu_keluarga\":\"122\",\"nik_jenazah\":\"1231234\",\"nama_lengkap_jenazah\":\"almsdsd\",\"jenis_kelamin_jenazah\":\"laki\",\"tempat_kelahiran_jenazah\":\"sleman\",\"tanggal_lahir_jenazah\":\"2020-11-25\",\"umur_jenazah\":\"122\",\"agama_jenazah\":\"islam\",\"pekerjaan_jenazah\":\"petani\",\"alamat_jenazah\":\"sleman\",\"anak_ke\":\"satu\",\"hari_kematian\":\"selasa\",\"tanggal_kematian\":\"2020-11-17\",\"tempat_meninggal\":\"rumah\",\"jam_meninggal\":\"2\",\"sebab\":\"sakit\",\"tempat_kematian\":\"selman\",\"yang_menerangkan\":\"lainnya\"}');
INSERT INTO `data_pengajuans` VALUES (5, 1, NULL, 'wakyu', 'pria', NULL, NULL, NULL, NULL, NULL, 'kawin', 'islam', NULL, '2020-11-23 00:26:40', '2020-11-23 00:26:40', '2');
INSERT INTO `data_pengajuans` VALUES (6, 1, NULL, 'warga1kolom ibu', 'pria', NULL, NULL, NULL, NULL, NULL, 'Kawin', 'Islam', NULL, '2020-11-12 11:47:09', '2020-11-12 11:47:53', '{\"nomer_kartu_keluarga\":\"122\",\"nama_kepala_keluarga\":\"jon\",\"nama_lengkap_bayi\":\"bayi lengkap\",\"jenis_kelamin_bayi\":\"laki\",\"tempat_dilahirkan\":\"halte\",\"tempat_kelahiran\":\"jogja\",\"hari_dilahirkan\":\"selasa\",\"tanggal_lahir\":\"2020-11-19\",\"jam_kelahiran\":\"3\",\"jenis_kelahiran\":\"Tunggal\",\"kelahiran_ke\":\"Satu\",\"penolong_kelahiran\":\"Suster\",\"berat_bayi\":\"4\",\"panjang_bayi\":\"2\",\"nik_ibu\":\"1113\",\"nama_lengkap_ibu\":\"wati ibu\",\"tempat_tangga_lahir_ibu\":\"jogja , 2\\/2\\/2020\",\"pekerjaan_ibu\":\"pedagang\",\"alamat_lengkap_ibu\":\"jakal km rt3 rw2\",\"kewarga_negaraan_ibu\":\"indonesia\",\"tanggal_pernikahan\":\"21\\/21\\/2020\"}');
INSERT INTO `data_pengajuans` VALUES (7, 5, NULL, 'pemesan surat', 'pria', NULL, NULL, NULL, NULL, NULL, 'kawin', 'islam', NULL, '2020-11-23 14:29:59', '2020-11-23 14:29:59', '1');
INSERT INTO `data_pengajuans` VALUES (8, 7, NULL, 'Iki', 'pria', NULL, NULL, NULL, NULL, NULL, 'kawin', 'islam', NULL, '2020-11-23 17:01:45', '2020-11-23 17:01:45', '2');
INSERT INTO `data_pengajuans` VALUES (9, 5, NULL, 'pemesan surat', 'pria', NULL, NULL, NULL, NULL, NULL, 'kawin', 'islam', NULL, '2020-11-23 21:26:13', '2020-11-23 21:26:13', '2');
INSERT INTO `data_pengajuans` VALUES (10, 2, NULL, 'Aku', 'pria', NULL, NULL, NULL, NULL, NULL, 'kawin', 'islam', NULL, '2020-11-23 21:34:28', '2020-11-23 21:34:28', '1');
INSERT INTO `data_pengajuans` VALUES (11, 5, NULL, 'wakyu', 'pria', NULL, NULL, NULL, NULL, NULL, 'kawin', 'islam', NULL, '2020-11-23 22:33:03', '2020-11-23 22:33:03', '5');
INSERT INTO `data_pengajuans` VALUES (12, 3, 3, 'pemesan surat', 'pria', NULL, NULL, NULL, NULL, NULL, 'kawin', 'islam', NULL, '2020-11-23 22:39:55', '2020-11-23 22:39:55', '1');
COMMIT;

-- ----------------------------
-- Table structure for data_pengantar_pindah
-- ----------------------------
DROP TABLE IF EXISTS `data_pengantar_pindah`;
CREATE TABLE `data_pengantar_pindah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nik` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `tempat_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` varchar(255) DEFAULT NULL,
  `no_kk` varchar(255) DEFAULT NULL,
  `nama_kk` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `desa` varchar(255) DEFAULT NULL,
  `kecamatan` varchar(255) DEFAULT NULL,
  `tujuan_alamat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tujuan_desa` varchar(255) DEFAULT NULL,
  `tujuan_kecamatan` varchar(255) DEFAULT NULL,
  `tujuan_kabupaten` varchar(255) DEFAULT NULL,
  `tujuan_provinsi` varchar(255) DEFAULT NULL,
  `jumlah_pindah` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of data_pengantar_pindah
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for data_pengantar_umum
-- ----------------------------
DROP TABLE IF EXISTS `data_pengantar_umum`;
CREATE TABLE `data_pengantar_umum` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) DEFAULT NULL,
  `nik` varchar(255) DEFAULT NULL,
  `tempat_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` varchar(255) DEFAULT NULL,
  `jk` varchar(255) DEFAULT NULL,
  `agama` varchar(255) DEFAULT NULL,
  `status_kawin` varchar(255) DEFAULT NULL,
  `pekerjaan` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `tujuan` varchar(255) DEFAULT NULL,
  `keperluan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of data_pengantar_umum
-- ----------------------------
BEGIN;
INSERT INTO `data_pengantar_umum` VALUES (1, NULL, '123123', NULL, NULL, '-- Agama --', NULL, '-- Status --', NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for data_permohonan_pindah
-- ----------------------------
DROP TABLE IF EXISTS `data_permohonan_pindah`;
CREATE TABLE `data_permohonan_pindah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_kk` varchar(255) DEFAULT NULL,
  `nama_kk` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `desa` varchar(255) DEFAULT NULL,
  `kecamatan` varchar(255) DEFAULT NULL,
  `kab` varchar(255) DEFAULT NULL,
  `provinsi` varchar(255) DEFAULT NULL,
  `kodepos` varchar(255) DEFAULT NULL,
  `nik_pemohon` varchar(255) DEFAULT NULL,
  `tempat_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `alasan_pindah` varchar(255) DEFAULT NULL,
  `tujuan_alamat_pindah` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tujuan_desa` varchar(255) DEFAULT NULL,
  `tujuan_kecamatan` varchar(255) DEFAULT NULL,
  `tujuan_kab` varchar(255) DEFAULT NULL,
  `tujuan_prov` varchar(255) DEFAULT NULL,
  `tujuan_kodepos` varchar(255) DEFAULT NULL,
  `jenis_pindah` varchar(255) DEFAULT NULL,
  `status_kk` varchar(255) DEFAULT NULL,
  `status_no_kk_pindah` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of data_permohonan_pindah
-- ----------------------------
BEGIN;
INSERT INTO `data_permohonan_pindah` VALUES (1, 'nomor kk', 'nama kk', 'alamat', 'desa', 'kemacataman', 'kab', 'prov', '555', '3402', 'yogya', '12123', 'nama', 'Pekerjaan', 'tujuan', NULL, NULL, 'tujuan kab', 'tujuan prov', 'tujuan kode', 'Kep. Keluarga', 'Numpang KK', NULL);
INSERT INTO `data_permohonan_pindah` VALUES (2, '65454544', 'nama kk', 'yogya.', 'yoga', 'kemacataman', 'yogya', 'yogya', '55188', '302121', 'Bantul', '12123', 'Yodi', 'Keluarga', 'tujuan', NULL, NULL, 'tujuan kab', 'tujuan prov', 'tujuan kode', 'Anggota Keluarga', 'Numpang KK', 'Numpang KK');
INSERT INTO `data_permohonan_pindah` VALUES (3, 'nomor kk', 'nama kk', 'alamat', 'yoga', 'kemacataman', 'yogya', 'yogya', '5555', '302121', 'Bantul', '14121994', 'addas', 'Keamanan', 'tujuan', NULL, NULL, 'tujuan kab', 'tujuan prov', '13123123', 'Kep. Keluarga', 'Membuat KK Baru', 'Membuat KK Baru');
INSERT INTO `data_permohonan_pindah` VALUES (4, 'nomor kk', 'nama kk', 'alamat', 'yoga', 'kemacataman', 'yogya', 'yogya', '5555', '302121', 'Bantul', '14121994', 'addas', 'Keamanan', 'tujuan', NULL, NULL, 'tujuan kab', 'tujuan prov', '13123123', 'Kep. Keluarga', 'Membuat KK Baru', 'Membuat KK Baru');
INSERT INTO `data_permohonan_pindah` VALUES (5, '65454544', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-- Pilih --', NULL, NULL, NULL, NULL, NULL, NULL, '-- Pilih --', '-- Pilih --', '-- Pilih --');
COMMIT;

-- ----------------------------
-- Table structure for data_permohonan_pindah_datang
-- ----------------------------
DROP TABLE IF EXISTS `data_permohonan_pindah_datang`;
CREATE TABLE `data_permohonan_pindah_datang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_kk` varchar(255) DEFAULT NULL,
  `nama_kk` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `desa` varchar(255) DEFAULT NULL,
  `kodepos` varchar(255) DEFAULT NULL,
  `kecamatan` varchar(255) DEFAULT NULL,
  `kabupaten` varchar(255) DEFAULT NULL,
  `provinsi` varchar(255) DEFAULT NULL,
  `nik_pemohon` varchar(255) DEFAULT NULL,
  `tmpt_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `tujuan_kk` varchar(255) DEFAULT NULL,
  `tujuan_no_kk` varchar(255) DEFAULT NULL,
  `tujuan_nama_kk` varchar(255) DEFAULT NULL,
  `tgl_datang` varchar(255) DEFAULT NULL,
  `tujuan_alamat` varchar(255) DEFAULT NULL,
  `tujuan_desa` varchar(255) DEFAULT NULL,
  `tujuan_kecamatan` varchar(255) DEFAULT NULL,
  `tujuan_kabupaten` varchar(255) DEFAULT NULL,
  `tujuan_provinsi` varchar(255) DEFAULT NULL,
  `tujuan_kodepos` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of data_permohonan_pindah_datang
-- ----------------------------
BEGIN;
INSERT INTO `data_permohonan_pindah_datang` VALUES (1, '0000002', 'Kui', 'yogya', 'yoga', '5555', 'yogya', NULL, 'yogya', '302121', NULL, '14141211', 'Yodi', 'Membuat KK Baru', '778457848', 'Aku', NULL, 'asdasdasd', 'asdasd', 'sdfdfg', 'dfgdfg', 'dfgdfg', '13123123');
INSERT INTO `data_permohonan_pindah_datang` VALUES (2, '0000002', 'Kui', 'yogya', 'yoga', '5555', 'yogya', NULL, 'yogya', '302121', NULL, '14141211', 'Yodi', 'Membuat KK Baru', '778457848', 'Aku', NULL, 'asdasdasd', 'asdasd', 'sdfdfg', 'dfgdfg', 'dfgdfg', '13123123');
COMMIT;

-- ----------------------------
-- Table structure for data_surat_pindah_datang
-- ----------------------------
DROP TABLE IF EXISTS `data_surat_pindah_datang`;
CREATE TABLE `data_surat_pindah_datang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_kk` varchar(255) DEFAULT NULL,
  `nama_kk` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `desa` varchar(255) DEFAULT NULL,
  `kodepos` varchar(255) DEFAULT NULL,
  `kecamatan` varchar(255) DEFAULT NULL,
  `kabupaten` varchar(255) DEFAULT NULL,
  `provinsi` varchar(255) DEFAULT NULL,
  `nik_pemohon` varchar(255) DEFAULT NULL,
  `tmpt_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `tujuan_kk` varchar(255) DEFAULT NULL,
  `tujuan_no_kk` varchar(255) DEFAULT NULL,
  `tujuan_nama_kk` varchar(255) DEFAULT NULL,
  `tgl_datang` varchar(255) DEFAULT NULL,
  `tujuan_alamat` varchar(255) DEFAULT NULL,
  `tujuan_desa` varchar(255) DEFAULT NULL,
  `tujuan_kecamatan` varchar(255) DEFAULT NULL,
  `tujuan_kabupaten` varchar(255) DEFAULT NULL,
  `tujuan_provinsi` varchar(255) DEFAULT NULL,
  `tujuan_kodepos` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of data_surat_pindah_datang
-- ----------------------------
BEGIN;
INSERT INTO `data_surat_pindah_datang` VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-- Pilih --', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `data_surat_pindah_datang` VALUES (2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-- Pilih --', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `data_surat_pindah_datang` VALUES (3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-- Pilih --', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `data_surat_pindah_datang` VALUES (4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-- Pilih --', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of failed_jobs
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for kategori_surats
-- ----------------------------
DROP TABLE IF EXISTS `kategori_surats`;
CREATE TABLE `kategori_surats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `kop_surat` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `kode_surat` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `alamat_instansi` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `margin_bawah` int DEFAULT NULL,
  `margin_atas` int DEFAULT NULL,
  `margin_kekanan` int DEFAULT NULL,
  `paragraf_awal` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `paragraf_akhir` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nomor_pegawai_ttd` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `jabatan_ttd` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nama_ttd` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `data_template` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of kategori_surats
-- ----------------------------
BEGIN;
INSERT INTO `kategori_surats` VALUES (1, 'surat keterangan kelahiran', '<p>p</p>', '472.11/nomer/220/P/X/2020', 'jl besi jangkang kaliurang km 14,4', 1, 1, 1, '<p>p</p>', '<p>p</p>', '11121212', 'Kepala Desa', 'Budiono', '\"{\\\"nama\\\":[\\\"nomer_kartu_keluarga\\\",\\\"nama_kepala_keluarga\\\",\\\"nama_lengkap_bayi\\\",\\\"jenis_kelamin_bayi\\\",\\\"tempat_dilahirkan\\\",\\\"tempat_kelahiran\\\",\\\"hari_dilahirkan\\\",\\\"tanggal_lahir\\\",\\\"jam_kelahiran\\\",\\\"jenis_kelahiran\\\",\\\"kelahiran_ke\\\",\\\"penolong_kelahiran\\\",\\\"berat_bayi\\\",\\\"panjang_bayi\\\",\\\"nik_ibu\\\",\\\"nama_lengkap_ibu\\\",\\\"tempat_tangga_lahir_ibu\\\",\\\"pekerjaan_ibu\\\",\\\"alamat_lengkap_ibu\\\",\\\"kewarga_negaraan_ibu\\\",\\\"tanggal_pernikahan\\\",\\\"nik_ayah\\\",\\\"nama_lengkap_ayah\\\",\\\"tempat_tanggal_lahir_ayah\\\",\\\"umur_ayah\\\",\\\"pakerjaan_ayah\\\",\\\"alamat_ayah\\\",\\\"kewarganegaraan_ayah\\\",\\\"nik_pelapor\\\",\\\"nama_lengkap_pelapor\\\",\\\"tempat_tanggal_lahir_pelapor\\\",\\\"umur_pelapor\\\",\\\"pekerjaan_pelapor\\\",\\\"alamat_pelapor\\\",\\\"tanggal_lapor\\\",\\\"nik_saksi1\\\",\\\"nama_lengkap_saksi1\\\",\\\"umur_saksi1\\\",\\\"alamat_saksi1\\\",\\\"nik_saksi2\\\",\\\"nama_lengkap_saksi2\\\",\\\"umur_saksi2\\\",\\\"alamat_saksi2\\\"],\\\"type\\\":[\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"date\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"date\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"date\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\"]}\"', '2020-11-12 11:40:26', '2020-11-12 12:21:08');
INSERT INTO `kategori_surats` VALUES (2, 'surat keteragan kematian', '<p>p</p>', '472.12/nomer/200', 'jl besi jangkang kaliurang km 14,4', 1, 1, 1, '<p>p</p>', '<p>p</p>', '11111', 'Kepala Desa', 'Budiono', '\"{\\\"nama\\\":[\\\"nama_kepa_keluarga\\\",\\\"nomer_kartu_keluarga\\\",\\\"nik_jenazah\\\",\\\"nama_lengkap_jenazah\\\",\\\"jenis_kelamin_jenazah\\\",\\\"tempat_kelahiran_jenazah\\\",\\\"tanggal_lahir_jenazah\\\",\\\"umur_jenazah\\\",\\\"agama_jenazah\\\",\\\"pekerjaan_jenazah\\\",\\\"alamat_jenazah\\\",\\\"anak_ke\\\",\\\"hari_kematian\\\",\\\"tanggal_kematian\\\",\\\"tempat_meninggal\\\",\\\"jam_meninggal\\\",\\\"sebab\\\",\\\"tempat_kematian\\\",\\\"yang_menerangkan\\\"],\\\"type\\\":[\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"date\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"date\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\"]}\"', '2020-11-12 13:29:25', '2020-11-12 13:29:25');
INSERT INTO `kategori_surats` VALUES (3, 'surat pengantar umum', '<p>PEMERINTAH KABUPATEN SLEMAN</p>\r\n\r\n<p>KECAMATAN NGEMPLAK</p>\r\n\r\n<p>PEMERINTAH DESA UMBULMARTANI</p>', '4721.21/210/p/bulan/2020', 'Grogolan, Umbulmartani, Ngemplak, Sleman, DIY 55584', 1, 1, 1, '<p>Yang bertanda tangan di bawah ini, menerangkan Permohonan PIndah Penduduk WNI dengan data debagai berikut:</p>', '<p>Adapun Pemohonan PIndah Penduduk WNI yang bersangkutan sebagaimana terlampir.</p>\r\n\r\n<p>Demikian surat Pengantar Pindah ini dibuat agar digunakan sebagaimana mestinya.</p>', '11121212', 'Kepala Desa', 'Budiono', '\"{\\\"nama\\\":[\\\"nik\\\",\\\"nama_lengkap\\\",\\\"tempat_lahir\\\",\\\"tanggal_lahir\\\",\\\"nomor_kartu_keluarga\\\",\\\"alamat_sekarang\\\",\\\"alamat_tujuan_pindah\\\",\\\"jumlah_keluarga__yang_pindah\\\"],\\\"type\\\":[\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"date\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\"]}\"', '2020-11-12 13:43:00', '2020-11-12 13:43:00');
INSERT INTO `kategori_surats` VALUES (4, 'surat pengantar pindah', '<p>c</p>', '10/p/X/2020', 'jl besi jangkang kaliurang km 14,4', 1, 1, 1, '<p>Saya yang bertanda tangan di bawah ini</p>\r\n\r\n<p>a. Nama:</p>\r\n\r\n<p>b Jabatan:</p>\r\n\r\n<p>dengan ini menrangkan bahwa:</p>', '<p>Berhubungan dengan keprluan yang bersangkutan, dimohon agar yang berwenang dapt memberikan bantuan serta fasilitas seperlunya.</p>\r\n\r\n<p>Demikina surat keterangan ini dibuat untuk dipergunakan seperlunya.</p>', '11121212', 'ssss12', 'Budiono', '\"{\\\"nama\\\":[\\\"nama\\\",\\\"nik\\\",\\\"tempat_lahir\\\",\\\"tanggal_lahir\\\",\\\"jenis_kelamin\\\",\\\"agama\\\",\\\"status_perkawinan\\\",\\\"pekerjaan\\\",\\\"alamat\\\",\\\"tujuan_ke\\\",\\\"keperluan\\\"],\\\"type\\\":[\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"date\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\",\\\"string\\\"]}\"', '2020-11-12 13:48:59', '2020-11-12 13:48:59');
INSERT INTO `kategori_surats` VALUES (5, 'formulir permohonan pindah', '<p>', '1234', 'jl besi jangkang', 1, 1, 1, '<p>', 'p', '1111111', '1111', 'Budiono', '121', '2020-11-22 23:33:03', '2020-11-22 23:33:07');
INSERT INTO `kategori_surats` VALUES (6, 'surat keterangan pindah datang', '<p>', '2222', 'jl besi', 1, 1, 1, 'pp', 'pp', '321', '31', 'Budiono', 'asds', '2020-11-22 23:34:09', '2020-11-22 23:34:15');
INSERT INTO `kategori_surats` VALUES (7, 'formulir permohonan pindah datang', '<p>', '3333', 'jl besi jangkah', 1, 1, 1, '112', '212', '21', '12', 'Budiono', '3232', '2020-11-22 23:34:58', '2020-11-22 23:35:02');
COMMIT;

-- ----------------------------
-- Table structure for keluarga_datang
-- ----------------------------
DROP TABLE IF EXISTS `keluarga_datang`;
CREATE TABLE `keluarga_datang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nik` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `masa_berlaku` varchar(255) DEFAULT NULL,
  `shdk` varchar(255) DEFAULT NULL,
  `id_perm_pindah` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of keluarga_datang
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for keluarga_perm_datang
-- ----------------------------
DROP TABLE IF EXISTS `keluarga_perm_datang`;
CREATE TABLE `keluarga_perm_datang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nik` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `masa_berlaku` varchar(255) DEFAULT NULL,
  `shdk` varchar(255) DEFAULT NULL,
  `id_perm_pindah` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of keluarga_perm_datang
-- ----------------------------
BEGIN;
INSERT INTO `keluarga_perm_datang` VALUES (7, '123456', 'Jodi', NULL, 'Kepala Keluarga', 2);
INSERT INTO `keluarga_perm_datang` VALUES (8, '654321', 'Jedi', NULL, 'Anak', 2);
INSERT INTO `keluarga_perm_datang` VALUES (9, '123421', 'Jada', NULL, 'Anak', 2);
COMMIT;

-- ----------------------------
-- Table structure for keluarga_pindah
-- ----------------------------
DROP TABLE IF EXISTS `keluarga_pindah`;
CREATE TABLE `keluarga_pindah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nik` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `masa_berlaku` varchar(255) DEFAULT NULL,
  `shdk` varchar(255) DEFAULT NULL,
  `id_perm_pindah` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of keluarga_pindah
-- ----------------------------
BEGIN;
INSERT INTO `keluarga_pindah` VALUES (5, '340212', 'Sri', 'SM', 'Saudara', 1);
INSERT INTO `keluarga_pindah` VALUES (6, '340302', 'Wah', 'SM', 'Anak', 1);
INSERT INTO `keluarga_pindah` VALUES (7, '123456', 'Jodi', '1', 'Kepala Keluarga', 2);
INSERT INTO `keluarga_pindah` VALUES (8, '123456', 'deny', '1', 'Kepala Keluarga', 2);
INSERT INTO `keluarga_pindah` VALUES (9, '340212', 'Jodi', 'sm', 'Kepala Keluarga', 2);
INSERT INTO `keluarga_pindah` VALUES (10, '1', 'deny', 'sm', 'sodara', 5);
COMMIT;

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
BEGIN;
INSERT INTO `migrations` VALUES (1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` VALUES (2, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES (3, '2019_08_19_000000_create_failed_jobs_table', 1);
INSERT INTO `migrations` VALUES (4, '2020_07_08_121641_create_kategori_surats_table', 1);
INSERT INTO `migrations` VALUES (5, '2020_07_08_121747_create_wargas_table', 1);
INSERT INTO `migrations` VALUES (6, '2020_07_08_121821_create_data_pengajuans_table', 1);
INSERT INTO `migrations` VALUES (7, '2020_07_08_121841_create_pesanans_table', 1);
INSERT INTO `migrations` VALUES (8, '2020_07_10_133820_add_tglpesan_to_pesanan_table', 1);
INSERT INTO `migrations` VALUES (9, '2020_09_09_001302_add_margin_instansi_in_kategori_surat', 1);
INSERT INTO `migrations` VALUES (10, '2020_09_23_001104_make_isambil_to_pesanan', 1);
INSERT INTO `migrations` VALUES (11, '2020_11_05_100133_add_column_to_data_pengajuan', 1);
COMMIT;

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of password_resets
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for pesanans
-- ----------------------------
DROP TABLE IF EXISTS `pesanans`;
CREATE TABLE `pesanans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data_pengajuan_id` bigint unsigned NOT NULL,
  `pemverifikasi_id` bigint unsigned DEFAULT NULL,
  `nomer_surat` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT '0: proses, 1: verifikasi, 2: jadi',
  `is_ambil` tinyint(1) NOT NULL DEFAULT '0',
  `tanggal_pesan` date DEFAULT NULL,
  `tanggal_verifikasi` date DEFAULT NULL,
  `tanggal_jadi` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of pesanans
-- ----------------------------
BEGIN;
INSERT INTO `pesanans` VALUES (1, 1, NULL, '472.11/nomer/220/P/X/2020/ Kec.Ngemplak/1 /XI/2020', '0', 0, '2020-11-12', '2020-11-12', NULL, '2020-11-12 11:41:52', '2020-11-12 11:42:24');
INSERT INTO `pesanans` VALUES (2, 6, NULL, '472.11/nomer/220/P/X/2020/ Kec.Ngemplak/1 /XI/2020', '0', 0, '2020-11-12', '2020-11-12', NULL, '2020-11-12 11:47:09', '2020-11-12 11:47:53');
INSERT INTO `pesanans` VALUES (3, 3, NULL, '472.11/nomer/220/P/X/2020/ Kec.Ngemplak/1 /XI/2020', '2', 1, '2020-11-12', '2020-11-22', '2020-11-23', '2020-11-12 12:27:28', '2020-11-23 00:46:34');
INSERT INTO `pesanans` VALUES (4, 4, NULL, '472.12/nomer/200/ Kec.Ngemplak/2 /XI/2020', '1', 0, '2020-11-12', '2020-11-12', NULL, '2020-11-12 13:34:05', '2020-11-12 13:34:59');
INSERT INTO `pesanans` VALUES (5, 5, NULL, '472.11/nomer/220/P/X/2020/ Kec.Ngemplak/1 /XI/2020', '1', 0, '2020-11-23', '2020-11-23', NULL, '2020-11-23 00:26:40', '2020-11-23 01:58:45');
INSERT INTO `pesanans` VALUES (7, 7, NULL, '1234/ Kec.Ngemplak/5 /XI/2020', '1', 0, '2020-11-23', '2020-11-23', NULL, '2020-11-23 14:29:59', '2020-11-23 17:02:14');
INSERT INTO `pesanans` VALUES (8, 8, NULL, '3333/ Kec.Ngemplak/7 /XI/2020', '0', 0, '2020-11-23', NULL, NULL, '2020-11-23 17:01:45', '2020-11-23 17:01:45');
INSERT INTO `pesanans` VALUES (9, 9, NULL, '1234/ Kec.Ngemplak/5 /XI/2020', '1', 0, '2020-11-23', '2020-11-23', NULL, '2020-11-23 21:26:13', '2020-11-23 21:53:32');
INSERT INTO `pesanans` VALUES (10, 10, NULL, '472.12/nomer/200/ Kec.Ngemplak/2 /XI/2020', '1', 0, '2020-11-23', '2020-11-23', NULL, '2020-11-23 21:34:28', '2020-11-23 22:42:16');
INSERT INTO `pesanans` VALUES (11, 11, NULL, '1234/ Kec.Ngemplak/5 /XI/2020', '1', 0, '2020-11-23', '2020-11-23', NULL, '2020-11-23 22:33:03', '2020-11-23 22:41:53');
INSERT INTO `pesanans` VALUES (12, 12, NULL, '4721.21/210/p/bulan/2020/ Kec.Ngemplak/3 /XI/2020', '1', 0, '2020-11-23', '2020-11-23', NULL, '2020-11-23 22:39:55', '2020-11-23 22:47:54');
COMMIT;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nomer_pegawai` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` VALUES (1, 'ATT123', 'deni', 'deni@gmail.com', NULL, '$2y$10$50mjVm94RqXPmGMdonGzpePa4Rx8U0lL//EBj6shPdafFUsnpDBBu', 'admin', NULL, '2020-11-12 11:36:29', '2020-11-12 11:36:29');
COMMIT;

-- ----------------------------
-- Table structure for wargas
-- ----------------------------
DROP TABLE IF EXISTS `wargas`;
CREATE TABLE `wargas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wargas_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of wargas
-- ----------------------------
BEGIN;
INSERT INTO `wargas` VALUES (1, 'warga', 'warga@gmail.com', '$2y$10$PcySRO8liqYf5HXzXllVRe5Dpb1ra/2jTFISBd9qN58i590pNqP8.', '2020-11-16 19:50:08', '2020-11-16 19:50:08');
INSERT INTO `wargas` VALUES (2, 'dito', 'dito@mail.com', '$2y$10$50mjVm94RqXPmGMdonGzpePa4Rx8U0lL//EBj6shPdafFUsnpDBBu', '2020-11-22 14:46:36', '2020-11-22 14:46:36');
INSERT INTO `wargas` VALUES (3, 'akuwarga', 'akuwarga@gmail.com', '$2y$10$8skzn4CJaoFfBacBk4scpuJCQBWQhv5SV2QEEYo6aPKSx0G/Anl3e', '2020-11-23 22:03:07', '2020-11-23 22:03:07');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
