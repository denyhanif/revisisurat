

<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-1">
        <h1 class="h3 mb-0 text-gray-800">Tambah Kategori Surat</h1>
    </div>

    <div class="row">
        <div class="col-md-12 card shadow mb-1">
            <form class="mt-3 mb-2 small" action="<?php echo e(route('kategori.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-4">
                    
                        <div class="form-group m-2">
                            <label class="mb-0" for="formGroupExampleInput">Alamat Instansi</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['alamat_instansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat_instansi" id="formGroupExampleInput" placeholder="Masukkan Alamat Instansi" value="<?php echo e(old('alamat_instansi')); ?>">
                                <?php $__errorArgs = ['alamat_instansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group m-2">
                            <label class="mb-0" for="formGroupExampleInput">Kode Surat</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['kode_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kode_surat" id="formGroupExampleInput" placeholder="Masukkan Kode Surat" value="<?php echo e(old('kode_surat')); ?>">
                                <?php $__errorArgs = ['kode_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group m-2">
                            <label class="text-sm mb-0" for="formGroupExampleInput">Nama Kategori Surat</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_kategori" id="formGroupExampleInput" placeholder="Masukkan Nama Kategori Surat" value="<?php echo e(old('nama_kategori')); ?>">
                                <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group m-2">
                            <label class="text-sm mb-0" for="formGroupExampleInput">Nama Pegawai</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="nama_ttd" id="formGroupExampleInput" 
                                placeholder="Masukkan Nama Pegawai" 
                                value="<?php echo e(old('nama_ttd')); ?>">
                                <?php $__errorArgs = ['nama_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group m-2">
                            <label class="text-sm mb-0" for="formGroupExampleInput">Jabatan</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['jabatan_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jabatan_ttd" id="formGroupExampleInput" placeholder="Masukkan Jabatan" value="<?php echo e(old('jabatan_ttd')); ?>">
                                <?php $__errorArgs = ['jabatan_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group m-2">
                            <label class="text-sm mb-0" for="formGroupExampleInput">NIP</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nomor_pegawai_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nomor_pegawai_ttd" id="formGroupExampleInput" placeholder="Masukkan NIP" value="<?php echo e(old('nomor_pegawai_ttd')); ?>">
                                <?php $__errorArgs = ['nomor_pegawai_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-row p-0" >
                            
                                <div class="col-md-3 form-group m-1">

                                <label class="text-sm mb-0" for="formGroupExampleInput">Jarak Atas</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['margin_atas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="margin_atas" id="formGroupExampleInput" placeholder=" cm" value="">
                                    <?php $__errorArgs = ['margin_atas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-3 form-group m-1">
                                    <label class="text-sm mb-0" for="formGroupExampleInput"> Jarak Bawah</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['margin_bawah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="margin_bawah" id="formGroupExampleInput" placeholder=" cm" value="">
                                        <?php $__errorArgs = ['margin_bawah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                  <div class="col-md-3 form-group m-1">
                                    <label class="text-sm mb-0" for="formGroupExampleInput">jarak kanan</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['margin_kekanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="margin_kekanan" id="formGroupExampleInput" placeholder=" cm" value="">
                                        <?php $__errorArgs = ['margin_kekanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                           

                            
                            
                        </div>
                        
                        
                        <div id="data-wrap">
                            <div id="input-wrap">
                                <hr>
                            
                                <?php if(old('data')): ?>
                                    <?php $__currentLoopData = old('data')['nama']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group row">
                                        <div class="row col-auto" style="flex: 1 1 1px;">
                                            <div class="col-6">
                                                <label>Nama</label>
                                                <input type="text" class="form-control <?php echo e($errors->has('data.nama.'.$loop->index)  ? 'is-invalid' : ''); ?>" placeholder="Masukkan Nama" name="data[nama][]" value="<?php echo e(old('data')['nama'][$loop->index]); ?>">
                                                <?php $__errorArgs = ['data.nama.'.$loop->index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-6">
                                                <label>Tipe</label>
                                                <select class="form-control" name="data[type][]">
                                                    <option value="string" <?php echo e(old('data')['type'][$loop->index] == "string" ?  "selected" : ''); ?>>teks</option>
                                                    <option value="date" <?php echo e(old('data')['type'][$loop->index] == "date" ?  "selected" : ''); ?>>tanggal</option>
                                                    <option value="numeric" <?php echo e(old('data')['type'][$loop->index] == "numeric" ?  "selected" : ''); ?>>nomor</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <div class="form-gorup row">
                                                <label style="opacity: 0;">hapus</label>
                                                <button class="form-control btn btn-danger">x</button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                <?php endif; ?>
                            </div>
                            <hr>
                        <div id="tambah" class="m-2">
                                <button class="btn btn-success" type="button"> tambah</button>
                        </div>

                        </div>
                    </div>
    
                    <div class="col-md-8">
                        <div class="form-group border-1">
                            <label>Nama Instansi</label>
                            <textarea name="kop_surat" id="kop_surat" class="form-control <?php $__errorArgs = ['kop_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="5" rows="1" style="height: 50%" placeholder="Masukan Kop Surat"><?php echo e(old('kop_surat')); ?></textarea>
                                <?php $__errorArgs = ['kop_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Isi Paragraf Awal</label>
                            <textarea name="paragraf_awal" id="paragraf_awal" class="form-control <?php $__errorArgs = ['paragraf_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10" placeholder="Masukan Paragraf Awal"><?php echo e(old('paragraf_awal')); ?></textarea>
                                <?php $__errorArgs = ['paragraf_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Isi Paragraf Akhir</label>
                            <textarea name="paragraf_akhir" id="paragraf_akhir" class="form-control <?php $__errorArgs = ['paragraf_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10" placeholder="Masukan Paragraf Akhir"><?php echo e(old('paragraf_akhir')); ?></textarea>
                                <?php $__errorArgs = ['paragraf_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="text-right">
                    <button class="btn btn-primary">Simpan</button>
                </div>
                
            </form>
        </div>
    </div>

    <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/22.0.0/classic/ckeditor.js"></script>
    
    <script>
        CKEDITOR.replace('kop_surat');
        var editor = CKEDITOR.replace('kop_surat');
        editor.resize( '100%', '350' )
    </script>
    <script>
        CKEDITOR.replace('paragraf_awal');
    </script>
    <script>
        CKEDITOR.replace('paragraf_akhir');
    </script>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            let dataWrap= $("#input-wrap");
            $("#tambah button").click(function(){
                let a = $("<div>")
                    .addClass("form-group row input-wrapwrap ")
                    .append([
                        $("<div>").addClass("row col-auto").css("flex",1)
                            .append([
                                $("<div>")
                                    .addClass("col-6")
                                    .append([
                                        $("<label>").html("Nama"),
                                        $("<input>").attr({
                                            "type":"text",
                                            "class":"form-control",
                                            "placeholder":"Masukkan Nama",
                                            "name": "data[nama][]"
                                        })    
                                    ]), 
                                    $("<div>")
                                    .addClass("col-6")
                                    .append([
                                        $("<label>").html("Tipe"),
                                        $("<select>").attr({
                                            "class":"form-control",
                                            "name": "data[type][]"
                                        })
                                        .append([
                                            $("<option>").val("string").html("teks"),
                                            $("<option>").val("date").html("tanggal"),
                                            $("<option>").val("numeric").html("nomor"),
                                        ])
                                    ])
                                
                            ]),
                            $("<div>").addClass(" col-auto")
                            .append([
                                $("<div>")
                                    .addClass("form-gorup row")
                                    .append([
                                        $("<label>").html("hapus").css("opacity",0),
                                        $("<button>").attr({
                                            "class":"form-control btn btn-danger hapus",
                                        }).html("x")
                                    ])

                            ])
                    ])
                dataWrap.append(a);
            })
            
            $('#input-wrap').on('click','.hapus',function(){
                $(this).closest('.input-wrapwrap').remove()
            })
        });
    </script>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frandito/Laravel/surat/resources/views/admin/kategori/create.blade.php ENDPATH**/ ?>