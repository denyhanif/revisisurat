
<?php $__currentLoopData = json_decode($kategori->data_template,true)['nama']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $data=json_decode($kategori->data_template,true);
    $tess= $loop->index;                               
    ?>
    <?php if($data['type'][$loop->index]=="string"): ?>
    <div class="form-group col-md-6">
                <label for="inputEmail4"><?php echo e(str_replace('_',' ',$data['nama'][$tess])); ?></label>
                <input type="text" name="<?php echo e($data['nama'][$tess]); ?>" class="form-control" id="inputEmail4">
    </div>
    <?php elseif($data['type'][$loop->index]=="date"): ?>
    <div class="form-group col-md-6">
                <label for="date"><?php echo e(str_replace('_',' ',$data['nama'][$tess])); ?></label>
                <input type="date" name="<?php echo e($data['nama'][$tess]); ?>" class="form-control" id="date">
    </div>
    <?php elseif($data['type'][$loop->index]=='numeric'): ?>
    
    <div class="form-group col-md-6">
                <label for="date"><?php echo e(str_replace('_',' ',$data['nama'][$tess])); ?></label>
                <input type="number" name="<?php echo e($data['nama'][$tess]); ?>" class="form-control" id="date">
    </div>
    <?php endif; ?>
        
    

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa\resources\views/admin/kategori/pakde.blade.php ENDPATH**/ ?>