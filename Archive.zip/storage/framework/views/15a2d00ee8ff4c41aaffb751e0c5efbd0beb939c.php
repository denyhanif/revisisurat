<?php $__env->startComponent('mail::message'); ?>
# Kepada <?php echo e($pengajuan->nama_pemesan); ?>


Pengajuan Surat <b><?php echo e($pengajuan->kategori->nama); ?></b> Anda Telah berhasil Diverifikasi oleh Admin.



Terimaksih,<br>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/frandito/Laravel/surat/resources/views/email/verifikasi.blade.php ENDPATH**/ ?>