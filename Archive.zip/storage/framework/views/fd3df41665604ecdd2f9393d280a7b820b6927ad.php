

<?php $__env->startSection('content'); ?>
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Data Pegawai</h1>
</div>

<div class="row mb-2">
    <a class="btn btn-primary" href="<?php echo e(route('admin.register')); ?>">Tambah Pegawai</a>
</div>

<div class="row">
    <div class="col-md-12 card shadow mb-4">
        <table class="table table-responsive-sm table-striped">
            <thead>
              <tr class="">
                <th scope="col">No</th>
                <th scope="col">Nomer Pegawai</th>
                <th scope="col">Nama</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <th scope="row"><?php echo e($no++); ?></th>
                  <td><?php echo e($row->nomer_pegawai); ?></td>
                  <td><?php echo e($row->nama); ?></td>
                  <td><?php echo e($row->email); ?></td>
                  <td><?php echo e($row->role); ?></td>
                  <td>
                    <form method="POST" action="<?php echo e(route('admin.destroy' , $row->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        
                        <a class="btn btn-warning" href="<?php echo e(route('admin.edit', $row->id)); ?>">Edit</a>
                        <button class="btn btn-danger">Hapus</button>
                      </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">Belum Ada Data</td>
                    </tr>
                <?php endif; ?>
            </tbody>
          </table>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa\resources\views/pegawai/index.blade.php ENDPATH**/ ?>