

<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tambah Data Pengajuan</h1>
    </div>

    <div class="row">
        <div class="col-md-12 card shadow mb-4">
            <form class="mt-3 mb-2" action="<?php echo e(route('warga.pengajuan.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="form-group col-md-8">
                        <label for="inputState">Pilih Kategori Surat</label>
                        <select name="id_kategori" id="inputKategori" class="form-control">
                            <option selected>Choose..</option>
                            <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option>Data Kategori Belum Ada !!!</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Pemesan Surat</label>
                        <input class="form-control" type="text" name="nama" >
                    
                    </div>
                    <div class="form-group" id="data-template-wrap">

                    </div>
                    
                  
                    <div class="text-left mt-4 mb-4">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>

    <script>
      $(document).ready(function(){
        $('#inputKategori').on('change',function(){
          var id = $(this).val()
            $.ajax({
              url: "<?php echo e(url('member/kategori/data/')); ?>/"+id,
              method: 'get',
              success: function(data){
                $('#data-template-wrap').html(data.view)
              },
              
            });
        })
      })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa - rev\resources\views/warga/pengajuan.blade.php ENDPATH**/ ?>