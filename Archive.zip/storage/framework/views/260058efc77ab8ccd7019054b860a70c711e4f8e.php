<?php $__env->startComponent('mail::message'); ?>
# Kepada <?php echo e($pengajuan->nama_pemesan); ?>


Pengajuan Surat <b><?php echo e($pengajuan->kategori->nama); ?></b> Anda Telah Jadi Silahkan Di Ambil Di Kelurahan.



Thanks,<br>
Desa Maju Mundur
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\TUGAS AKHIR\pengajuan-desa\resources\views/email/jadi.blade.php ENDPATH**/ ?>