

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-1">
  <h1 class="h3 mb-0 text-gray-800">Riwayat</h1>
</div>
<div class="row">
    <div class="col-md-12 shadow card mb-4 pt-3">
        <table id="table_id" class="table dt-responsive table-striped table-bordered">
            <thead class="border-none">
              <tr>
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Jenis Surat</th>
                <th scope="col">Tanggal Jadi</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <th scope="row"><?php echo e($no++); ?></th>
                  <td><?php echo e($row->nama_pemesan); ?></td>
                  <td><?php echo e($row->kategori->nama); ?></td>
                  <td><?php echo e($row->tanggal_jadi()); ?></td>
                  <td><?php echo $row->status_label; ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">Belum Ada Data</td>
                    </tr>
                <?php endif; ?>
            </tbody>
          </table>

          <div class="text-center">
              <?php echo e($pengajuan->links()); ?>

          </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>


<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>

<script>
        $(document).ready( function () {
              $('#table_id').DataTable();
          } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa - rev\resources\views/admin/riwayat.blade.php ENDPATH**/ ?>