
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Surat Keterangan lalal</title>
    
</head>

<body >
    <table border="1px" align="center " style="margin-top: -20px ;margin_left:30px;" >
            <tr>
                <td style="margin-top: 0">
                    <center ><font align="center " size="4" style="font-weight: bold;margin-top: -20px;margin_right:40px">kop surat</font>
                
                    <font size="3">alamat instansi</font>
                    </center>
                </td>
            </tr>
            <hr>
            </table>
        <br>
        <br>
        <table align="center" border="" >
            <tr >
                <td align="center" ><b>Surat Pengantar Kematian</b><hr style="margin-top: 0" ></td>
            </tr>
            <tr align="center" style="margin-top: 0">
                <td><center>Nomer Surat</center></td>
            </tr>
        </table>
        <br>
        <table style="margin-bottom: cm;margin_left:30px;margin_right:30px" align="justify" border="">
            <tr>
                <td align="justify">paragraf awal</td>
            </tr>
        </table>
        


        <table style="margin-left: cm" align="justify" border="">
            <tr><td height=""></td></tr>
            <tr >
                <td>Dengan Ini Menerangkan Bahwa :</td>
            </tr>
            <tr>
                <td>Nama Lengkap</td>
                <td>:nama pemesan</td>
            </tr>
            

        </table>
        
        <table style="margin-bottom: 0cm;margin_left:30px;margin_right:30px" align="justify" border="">
            <tr><td height=""></td></tr>
            <tr>
                <td align="justify" >paragraf akhir</td>
            </tr>
        </table>

        <table align="right" border="" style="margin_left:450px;margin_right:30px ">
            <tr><td height=""></td></tr>
            <tr style="">
                <td>Yogyakarta, 29-90202</td>
            </tr>
            <tr align="center">
                <td>jabatan</td>
            </tr>
            <tr ><td height="50"></td></tr>
            <tr align="center">
                <td><b>nama</b></td>
            </tr>
            <tr align="center">
                <td><b>111</b></td>
            </tr>
        </table>
</body>
</html><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa - rev\resources\views/admin/kategori/templateSurat/surat.blade.php ENDPATH**/ ?>