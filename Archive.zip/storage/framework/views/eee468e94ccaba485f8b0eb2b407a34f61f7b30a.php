


<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
   

    <div class="row align-items-md-center">
        <div class="card col-md-12 shadow  m-2 ml-3">
            <p style="text-align:center;" class="mb-0" >
                <img class="aligncenter " style="height: 300px ; width:300px; border:none" src=" <?php echo e(asset('img/n.png')); ?>"  alt="">

            </p>
            
            <h3 class="text-center mb-4 ">Selamat Datang di aplikasi pemesanan surat Kecamatan Ngemplak </h3>
            <div class="text-center mt-1 mb-3">
                <a class="btn btn-primary" href="<?php echo e(route('warga.dashboard')); ?>"> Pesan surat</a>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa\resources\views/warga/homewarga.blade.php ENDPATH**/ ?>