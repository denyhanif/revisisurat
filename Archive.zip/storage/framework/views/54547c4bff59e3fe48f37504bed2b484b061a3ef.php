<?php echo e($slot); ?>

<?php /**PATH /Users/frandito/Laravel/surat/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>