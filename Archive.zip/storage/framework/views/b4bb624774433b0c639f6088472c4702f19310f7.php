<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-1">
        <h1 class="h3 mb-0 text-gray-800">Verifikasi Surat Keterangan Kematian</h1>
    </div>

    <div class="row">
        <div class="col-md-12 card shadow mb-4">
            <form class="mt-3 mb-2" action="<?php echo e(route('send.verifikasi')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>                    
                    <input hidden value="<?php echo e($data->pengajuan_id); ?>" name="id_pengaju" >
                    <input hidden value="<?php echo e($data->pesanan_id); ?>" name="id_pesanan" >
                    <input hidden value="<?php echo e($data->halaman); ?>" name="kat" >
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Pemesan Surat</label>
                        <input class="form-control" type="text" name="nama_pemesan" value="<?php echo e($data->nama_pemesan); ?>">
                    </div>    
                    <div class="form-group col-md-8">
                        <label for="inputState">Nomor Kartu Keluarga</label>
                        <input class="form-control" type="text" name="no_kk" value="<?php echo e($data->no_kk); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Kepala Keluarga</label>
                        <input class="form-control" type="text" name="nm_kk" value="<?php echo e($data->nama_kk); ?>">
                    </div>
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Jenazah</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="nik" value="<?php echo e($data->nik); ?>">
                    </div>     
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="nama" value="<?php echo e($data->nama); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Jenis Kelamin</label>
                        <select name="jk" class="form-control">
                            <?php if( $data->jk == "L"): ?>
                            <option value="L">Laki - Laki</option>
                            <?php else: ?>
                            <option value="P">perempuan</option>
                            <?php endif; ?>
                        </select>
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat lahir</label>
                        <input class="form-control" type="text" name="tmpt_lahir" value="<?php echo e($data->tmpt_lahir); ?>">
                    </div>    
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir</label>
                        <input class="form-control" type="text" name="tgl_lahir" value="<?php echo e($data->tgl_lahir); ?>">
                    </div>      
                    <div class="form-group col-md-8">
                        <label for="inputState">Agama</label>
                        <select name="agama" class="form-control">
                            <?php switch($data->agama):
                                case ('islam'): ?>
                                <option value="islam">Islam</option>   
                                    <?php break; ?>
                                <?php case ('katholik'): ?>
                                <option value="katholik">Katholik</option>
                                    <?php break; ?>
                                <?php case ('kristen'): ?>
                                <option value="kristen">Kristen</option>   
                                    <?php break; ?>
                                <?php case ('hindhu'): ?>
                                <option value="hindhu">Hindhu</option>
                                    <?php break; ?>
                                <?php case ('budha'): ?>
                                <option value="budha">Budha</option>
                                    <?php break; ?>                                
                            <?php endswitch; ?>  
                        </select>
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Pekerjaan</label>
                        <input class="form-control" type="text" name="pekerjaan" value="<?php echo e($data->pekerjaan); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="alamat" value="<?php echo e($data->alamat); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Anak Ke</label>
                        <input class="form-control" type="number" name="anak_ke" value="<?php echo e($data->anak_ke); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Meninggal Tanggal</label>
                        <input class="form-control" type="number" name="meninggal_tgl" value="<?php echo e($data->meninggal_tgl); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Meninggal</label>
                        <input class="form-control" type="number" name="tmpt_meninggal" value="<?php echo e($data->tmpt_meninggal); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Sebab Meninggal</label>
                        <input class="form-control" type="number" name="sebab" value="<?php echo e($data->sebab); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Kematian</label>
                        <input class="form-control" type="number" name="tmpt_kematian" value="<?php echo e($data->tmpt_kematian); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Yang Menerangkan</label>
                        <input class="form-control" type="number" name="menerangkan" value="<?php echo e($data->menerangkan); ?>">
                    </div>
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Ibu</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="ibu_nik" value="<?php echo e($data->ibu_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="ibu_nm" value="<?php echo e($data->ibu_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Lahir</label>
                        <input class="form-control" type="text" name="ibu_tmpt_lahir" value="<?php echo e($data->ibu_tmpt_lahir); ?>" >
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir</label>
                        <input class="form-control" type="text" name="ibu_tgl_lahir" value="<?php echo e($data->ibu_tgl_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Pekerjaan</label>
                        <input class="form-control" type="text" name="ibu_pekerjaan" value="<?php echo e($data->ibu_pekerjaan); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="ibu_almt" value="<?php echo e($data->ibu_alamat); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Kewarganegaraan</label>
                        <input class="form-control" type="text" name="ibu_warganegara" value="<?php echo e($data->ibu_kewarganegaraan); ?>">
                    </div> 
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Ayah</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="ayah_nik" value="<?php echo e($data->ayah_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="ayah_nm" value="<?php echo e($data->ayah_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Lahir</label>
                        <input class="form-control" type="text" name="ayah_tmpt_lahir" value="<?php echo e($data->ayah_tmpt_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir</label>
                        <input class="form-control" type="text" name="ayah_tgl_lahir" value="<?php echo e($data->ayah_tgl_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Pekerjaan</label>
                        <input class="form-control" type="text" name="ayah_pekerjaan" value="<?php echo e($data->ayah_pekerjaan); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="ayah_almt" value="<?php echo e($data->ayah_alamat); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Kewarganegaraan</label>
                        <input class="form-control" type="text" name="ayah_warganegara" value="<?php echo e($data->ayah_kewarganegaraan); ?>">
                    </div> 
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Pelapor</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="pelapor_nik" value="<?php echo e($data->pelapor_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="pelapor_nm" value="<?php echo e($data->pelapor_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Lahir</label>
                        <input class="form-control" type="text" name="pelapor_tmpt_lahir" value="<?php echo e($data->pelapor_tmp_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir</label>
                        <input class="form-control" type="text" name="pelapor_tgl_lahir" value="<?php echo e($data->pelapor_tgl_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Umur</label>
                        <input class="form-control" type="number" name="pelapor_umur" value="<?php echo e($data->pelapor_umur); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Pekerjaan</label>
                        <input class="form-control" type="text" name="pelapor_pekerjaan" value="<?php echo e($data->pelapor_kerja); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="pelapor_almt" value="<?php echo e($data->pelapor_alamat); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lapor</label>
                        <input class="form-control" type="text" name="tgl_lapor" value="<?php echo e($data->tgl_lapor); ?>">
                    </div> 

                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Saksi 1</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="saksi1_nik" value="<?php echo e($data->saksi_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="saksi1_nm" value="<?php echo e($data->saksi_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Umur</label>
                        <input class="form-control" type="number" name="saksi1_umur" value="<?php echo e($data->saksi_umur); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="saksi1_almt" value="<?php echo e($data->saksi_alamat); ?>">
                    </div> 
                    <div class="text-left mt-4 mb-4">
                        <button type="submit" class="btn btn-primary">Verifikasi</button>
                    </div>
            </form>
            <form class="mt-3 mb-2" action="<?php echo e(route('tolak')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input hidden value="<?php echo e($data->halaman); ?>" name="kat" >
                <input hidden value="<?php echo e($data->pesanan_id); ?>" name="idpesantolak" >
                <div class="text-left mb-4">
                    <button type="submit" class="btn btn-danger">Tolak</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frandito/Laravel/surat/resources/views/admin/dashboard/verifMati.blade.php ENDPATH**/ ?>