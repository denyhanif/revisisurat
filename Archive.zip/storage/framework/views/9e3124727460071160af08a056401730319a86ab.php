[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\TUGAS AKHIR\pengajuan-desa\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>