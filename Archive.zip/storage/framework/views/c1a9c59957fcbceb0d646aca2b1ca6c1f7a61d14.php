<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-1">
        <h1 class="h3 mb-0 text-gray-800">Verifikasi Surat Keterangan Kelahiran</h1>
    </div>

    <div class="row">
        <div class="col-md-12 card shadow mb-4">
            <form class="mt-3 mb-2" action="<?php echo e(route('send.verifikasi')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>                    
                    <input hidden value="<?php echo e($data->pengajuan_id); ?>" name="id_pengaju" >
                    <input hidden value="<?php echo e($data->pesanan_id); ?>" name="id_pesanan" >
                    <input hidden value="<?php echo e($data->halaman); ?>" name="kat" >
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Pemesan Surat</label>
                        <input class="form-control" type="text" name="nama_pemesan" value="<?php echo e($data->nama_pemesan); ?>">
                    </div>    
                    <div class="form-group col-md-8">
                        <label for="inputState">Nomor Surat</label>
                        <input class="form-control" type="text" name="nama_pemesan" value="<?php echo e($data->nomer_surat); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Nomor Kartu Keluarga</label>
                        <input class="form-control" type="text" name="no_kk" value="<?php echo e($data->no_kk); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Kepala Keluarga</label>
                        <input class="form-control" type="text" name="nm_kk" value="<?php echo e($data->nama_kk); ?>">
                    </div>
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Bayi / Anak</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK (Kosongkan Jika Tidak Ada)</label>
                        <input class="form-control" type="text" name="nik" value="<?php echo e($data->nik); ?>">
                    </div>     
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="nama_bayi" value="<?php echo e($data->nama); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Jenis Kelamin</label>
                        <select name="jk" class="form-control">
                            <?php if( $data->jk == "L"): ?>
                            <option value="L">Laki - Laki</option>
                            <?php else: ?>
                            <option value="P">perempuan</option>
                            <?php endif; ?>
                        </select>
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Dilahirkan</label>
                        <input class="form-control" type="text" name="tmpt_lahiran" value="<?php echo e($data->tmpt_lahiran); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Kelahiran</label>
                        <input class="form-control" type="text" name="tmpt_lahir" value="<?php echo e($data->tmpt_lahir); ?>">
                    </div>    
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir & Jam Lahir</label>
                        <input class="form-control" type="text" name="tgl_lahir" value="<?php echo e($data->tgl_lahir); ?>">
                    </div>      
                    <div class="form-group col-md-8">
                        <label for="inputState">Jenis Kelahiran</label>
                        <input class="form-control" type="text" name="jns_lahiran" value="<?php echo e($data->jenis_kelahiran); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Kelahiran Ke (dengan huruf)</label>
                        <input class="form-control" type="text" name="kelahiran_ke" value="<?php echo e($data->kelahiran_ke); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Penolong Kelahiran</label>
                        <input class="form-control" type="text" name="pnlg_kelahiran" value="<?php echo e($data->penolong_lahir); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Berat Bayi (Dalam kg)</label>
                        <input class="form-control" type="number" name="berat" value="<?php echo e($data->berat); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Panjang Bayi (Dalam cm)</label>
                        <input class="form-control" type="number" name="panjang" value="<?php echo e($data->panjang); ?>">
                    </div>
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Ibu</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="ibu_nik" value="<?php echo e($data->ibu_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="ibu_nm" value="<?php echo e($data->ibu_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Lahir</label>
                        <input class="form-control" type="text" name="ibu_tmpt_lahir" value="<?php echo e($data->ibu_tmpt_lahir); ?>" >
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir</label>
                        <input class="form-control" type="text" name="ibu_tgl_lahir" value="<?php echo e($data->ibu_tgl_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Pekerjaan</label>
                        <input class="form-control" type="text" name="ibu_pekerjaan" value="<?php echo e($data->ibu_pekerjaan); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="ibu_almt" value="<?php echo e($data->ibu_alamat); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Kewarganegaraan</label>
                        <input class="form-control" type="text" name="ibu_warganegara" value="<?php echo e($data->ibu_kewarganegaraan); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Pencatatan Perkawinan</label>
                        <input class="form-control" type="text" name="ibu_tgl_kawin" value="<?php echo e($data->ibu_tgl_kawin); ?>">
                    </div> 
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Ayah</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="ayah_nik" value="<?php echo e($data->ayah_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="ayah_nm" value="<?php echo e($data->ayah_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Lahir</label>
                        <input class="form-control" type="text" name="ayah_tmpt_lahir" value="<?php echo e($data->ayah_tmpt_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir</label>
                        <input class="form-control" type="text" name="ayah_tgl_lahir" value="<?php echo e($data->ayah_tgl_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Pekerjaan</label>
                        <input class="form-control" type="text" name="ayah_pekerjaan" value="<?php echo e($data->ayah_pekerjaan); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="ayah_almt" value="<?php echo e($data->ayah_alamat); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Kewarganegaraan</label>
                        <input class="form-control" type="text" name="ayah_warganegara" value="<?php echo e($data->ayah_kewarganegaraan); ?>">
                    </div> 
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Pelapor</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="pelapor_nik" value="<?php echo e($data->pelapor_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="pelapor_nm" value="<?php echo e($data->pelapor_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Lahir</label>
                        <input class="form-control" type="text" name="pelapor_tmpt_lahir" value="<?php echo e($data->pelapor_tmp_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir</label>
                        <input class="form-control" type="text" name="pelapor_tgl_lahir" value="<?php echo e($data->pelapor_tgl_lahir); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Umur</label>
                        <input class="form-control" type="number" name="pelapor_umur" value="<?php echo e($data->pelapor_umur); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Pekerjaan</label>
                        <input class="form-control" type="text" name="pelapor_pekerjaan" value="<?php echo e($data->pelapor_kerja); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="pelapor_almt" value="<?php echo e($data->pelapor_alamat); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lapor</label>
                        <input class="form-control" type="text" name="tgl_lapor" value="<?php echo e($data->tgl_lapor); ?>">
                    </div> 

                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Saksi 1</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="saksi1_nik" value="<?php echo e($data->saksi_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="saksi1_nm" value="<?php echo e($data->saksi_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Umur</label>
                        <input class="form-control" type="number" name="saksi1_umur" value="<?php echo e($data->saksi_umur); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="saksi1_almt" value="<?php echo e($data->saksi_alamat); ?>">
                    </div> 

                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Saksi 2</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK</label>
                        <input class="form-control" type="text" name="saksi2_nik" value="<?php echo e($data->saksi_2_nik); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="saksi2_nm" value="<?php echo e($data->saksi_2_nama); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Umur</label>
                        <input class="form-control" type="number" name="saksi2_umur" value="<?php echo e($data->saksi_2_umur); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="saksi2_almt" value="<?php echo e($data->saksi_2_alamat); ?>">
                    </div> 
                    <div class="text-left mt-4 mb-4">
                        <button type="submit" class="btn btn-primary">Verifikasi</button>
                    </div>
            </form>
            <form class="mt-3 mb-2" action="<?php echo e(route('tolak')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input hidden value="<?php echo e($data->halaman); ?>" name="kat" >
                <input hidden value="<?php echo e($data->pesanan_id); ?>" name="idpesantolak" >
                <div class="text-left mb-4">
                    <button type="submit" class="btn btn-danger">Tolak</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frandito/Laravel/surat/resources/views/admin/dashboard/verifLahir.blade.php ENDPATH**/ ?>