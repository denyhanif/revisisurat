<?php echo e($slot); ?>

<?php /**PATH D:\TUGAS AKHIR\pengajuan-desa\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>