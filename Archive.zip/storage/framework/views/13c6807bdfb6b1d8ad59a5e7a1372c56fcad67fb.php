

<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-1">
        <h1 class="h3 mb-0 text-gray-800">Tambah Data Pengajuan</h1>
    </div>

    <div class="row">
        <div class="col-md-12 card shadow mb-4">
            <form class="mt-3 mb-2" action="<?php echo e(route('form-surat')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="form-group col-md-8">
                        <label for="inputState">Pilih Kategori Surat</label>
                        <select name="id_kategori" id="inputKategori" class="form-control">
                            <option selected>-- Pilih Kategori --</option>
                            <option value="1">Surat Keterangan Kelahiran</option>
                            <option value="2">Surat Keterangan Kematian</option>
                            <option value="3">Surat Pengantar Umum</option>
                            <option value="4">Surat Pengantar Pindah</option>
                            <option value="5">Formulir Permohonan Pindah</option>
                            <option value="6">Surat Keterangan Pindah Datang</option>
                            <option value="7">Formulir Permohonan Pindah Datang</option>
                        </select>
                    </div>
                    
                                 
                    <div class="text-left mt-4 mb-4">
                        <button type="submit" class="btn btn-primary">Lanjut</button>
                    </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frandito/Laravel/surat/resources/views/admin/pengajuan/create.blade.php ENDPATH**/ ?>