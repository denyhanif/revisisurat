
<html lang="en">
<head>
    <title>Surat Keterangan Kelahiran</title>
</head>
<table style="font-size:11px; margin-top: 10px; border: 1px solid black;">
    <tr>
        <td style="margin-top: 0">
           <b>KODE . F-2.01</b> 
        </td>
</table>
<table border="" width="50%" style="font-size:11px; margin-top: 10px">
    <tr>
        <td style="margin-top: 0">
           Pemerintah Desa/Kelurahan 
        </td>
        <td style="margin-top: 0">
            <b>: UMBULMARTANI</b>
         </td>
    </tr>
    <tr>
        <td style="margin-top: 0">
           Kecamatan
        </td>
        <td style="margin-top: 0">
            <b>: NGEMPLAK</b>
         </td>
    </tr>
    <tr>
        <td style="margin-top: 0">
           Kabupaten
        </td>
        <td style="margin-top: 0">
            <b>: SLEMAN</b>
         </td>
    </tr>
</table>

<br>
<br>
<table align="center" style="" border="">
    <tr>
        <td align="center"><b>SURAT KETERANGAN KELAHIRAN</b><hr></td>
    </tr>
    <tr>
        <td><center>Nomer Surat  <?php echo e($pengajuan->nomer_surat); ?></center></td>
    </tr>
</table>
<br>
<table style="margin-left: 1.5cm; font-size:11px;" border="">
    <tr>
        <td>1. Nomor Kartu Keluarga</td>
        <td>: <?php echo e($pengajuan->no_kk); ?></td>
    </tr>
    <tr>
        <td>2. Nama Kepala Kartu Keluarga</td>
        <td>: <?php echo e($pengajuan->nama_kk); ?></td>
    </tr>
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
<tr>
    <td>
        <b>BAYI/ANAK</b>
    </td>
</tr>
<tr>
    <td>
        <table style="margin-left: 1.5cm;">
            <tr>
                <td>1. NIK</td>
                <td>: </td>
            </tr>
            <tr>
                <td>2. Nama</td>
                <td>: <?php echo e($pengajuan->nama); ?></td>
            </tr>
            <tr>
                <td>3. Jenis Kelamin</td>
                <td>: </td>
            </tr>
            <tr>
                <td>4. Tempat Kelahiran</td>
                <td>: </td>
            </tr>
            <tr>
                <td>5. Tempat Lahir</td>
                <td>: </td>
            </tr>
        </table>
    </td>
</tr> 
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
    <tr>
        <td>
            <b>IBU</b>
        </td>
    </tr>
    <tr>
        <td>
            <table style="margin-left: 1.5cm;">
                <tr>
                    <td>1. NIK</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>2. Nama</td>
                    <td>: <?php echo e($pengajuan->nama); ?></td>
                </tr>
                <tr>
                    <td>3. Jenis Kelamin</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>4. Tempat Kelahiran</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>5. Tempat Lahir</td>
                    <td>: </td>
                </tr>
            </table>
        </td>
    </tr> 
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
    <tr>
        <td>
            <b>AYAH</b>
        </td>
    </tr>
    <tr>
        <td>
            <table style="margin-left: 1.5cm;">
                <tr>
                    <td>1. NIK</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>2. Nama</td>
                    <td>: <?php echo e($pengajuan->nama); ?></td>
                </tr>
                <tr>
                    <td>3. Jenis Kelamin</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>4. Tempat Kelahiran</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>5. Tempat Lahir</td>
                    <td>: </td>
                </tr>
            </table>
        </td>
    </tr> 
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
    <tr>
        <td>
            <b>PELAPOR</b>
        </td>
    </tr>
    <tr>
        <td>
            <table style="margin-left: 1.5cm;">
                <tr>
                    <td>1. NIK</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>2. Nama</td>
                    <td>: <?php echo e($pengajuan->nama); ?></td>
                </tr>
                <tr>
                    <td>3. Jenis Kelamin</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>4. Tempat Kelahiran</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>5. Tempat Lahir</td>
                    <td>: </td>
                </tr>
            </table>
        </td>
    </tr> 
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
    <tr>
        <td>
            <b>SAKSI</b>
        </td>
    </tr>
    <tr>
        <td>
            <table style="margin-left: 1.5cm;">
                <tr>
                    <td>1. NIK</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>2. Nama</td>
                    <td>: <?php echo e($pengajuan->nama); ?></td>
                </tr>
                <tr>
                    <td>3. Jenis Kelamin</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>4. Tempat Kelahiran</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>5. Tempat Lahir</td>
                    <td>: </td>
                </tr>
            </table>
        </td>
    </tr> 
    </table>
    <table style="margin-left: 1.5cm;">
        <tr>
            <td>NIK</td>
            <td>Nama</td>
            <td>Masa Berlaku</td>
            <td>SHDK</td>
        </tr>
        <?php $__currentLoopData = $data_kel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->nik); ?></td>
            <td><?php echo e($data->nama); ?></td>
            <td><?php echo e($data->masa_berlaku); ?></td>
            <td><?php echo e($data->shdk); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<table  style="margin-top: <?php echo e($kategori->margin_bawah); ?>cm" align="left" border="">
    <tr><td height="100"></td></tr>
    <tr>
        <td><?php echo $kategori->paragraf_akhir; ?></td>
    </tr>
</table>

<table align="right" border="">
    <tr><td height="70"></td></tr>
    <tr>
        <td>Yogyakarta, <?php echo e(tgl_indo(Carbon\Carbon::parse(now())->format('Y-m-d'))); ?></td>
    </tr>
    <tr>
        <td><?php echo e($kategori->jabatan_ttd); ?></td>
    </tr>
    <tr><td height="50"></td></tr>
    <tr>
        <td><b><?php echo e($kategori->nama_ttd); ?></b></td>
    </tr>
    <tr>
        <td><b><?php echo e($kategori->nomor_pegawai_ttd); ?></b></td>
    </tr>
</table>
<body>
    
</body>
</html>
<?php /**PATH /Users/frandito/Laravel/surat/resources/views/surat.blade.php ENDPATH**/ ?>