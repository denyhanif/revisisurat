


<?php $__env->startSection('content'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Riwayat</h1>
</div>
<div class="row">
    <div class="col-md-12 card shadow ml-1 mb-4">
        <table class="table table-responsive-sm table-striped ">
            <thead >
              <tr class="">
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Jenis Surat</th>
                <th scope="col">Tanggal Pesan</th>
                <th scope="col">Tanggal Verifikasi</th>
                <th scope="col">Tanggal Jadi</th>
                <th scope="col">Status</th>
                <th scope="col"> File</th>
              </tr>
            </thead>
             
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <th scope="row"><?php echo e($no++); ?></th>
                  <td><?php echo e($row->nama_pemesan); ?></td>
                  <td><?php echo e($row->kategori->nama); ?></td>
                  <td><?php echo e($row->pesanan->tanggal_pesan); ?></td>
                  <td>
                    <?php if($row->pesanan->tanggal_verifikasi == null): ?>
                    <?php echo e('belum diverifikasi'); ?>

                    <?php else: ?>
                    <?php echo e($row->pesanan->tanggal_verifikasi); ?>

                    <?php endif; ?>
                  </td>
                  <td><?php echo e($row->tanggal_jadi()); ?></td>
                  <td>
                    <?php echo $row->status_label; ?></td>
                  <td>
                    <?php if( $row->pesanan->status==2): ?>
                    <a target="_blank" class="btn btn-success" href="<?php echo e(route('print.surat.warga', $row->id)); ?>">Unduh</a>
                    <?php else: ?>
                    Belum ada file
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">Belum Ada Data</td>
                    </tr>
                <?php endif; ?>
            </tbody>
          </table>

          <div class="text-center">
              <?php echo e($pengajuan->links()); ?>

          </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa - rev\resources\views/warga/riwayat.blade.php ENDPATH**/ ?>