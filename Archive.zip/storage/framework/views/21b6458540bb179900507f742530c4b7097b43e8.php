
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
          <div class="sidebar-brand-icon rotate-n-15">
            
          </div>
          <div class="sidebar-brand-text mx-3">Pengajuan <sup>Surat</sup></div>
        </a>


        
        <!-- Divider -->
        <hr class="sidebar-divider my-0">
        
        <?php if(auth()->user()): ?>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
        <!-- Dashboard -->
        <li class="nav-item <?php echo e(Request::path() === 'Administrator/home' ? 'active' : ''); ?>">
          <a class="nav-link" href="<?php echo e(route('home.index')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
        </li>
  
        <!-- Divider -->
        <hr class="sidebar-divider">
  
        
  
        <!-- Tambah Pengajuan -->
        <li class="nav-item <?php echo e(Request::path() === 'Administrator/pengajuan/create' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('pengajuan.create')); ?>">
              <i class="fas fa-fw fa-tachometer-alt"></i>
              <span>Tambah Pengajuan</span></a>
          </li>

        
        <!-- Divider -->
        <hr class="sidebar-divider">
  
        <!-- Riwayat -->
        <li class="nav-item <?php echo e(Request::path() === 'Administrator/riwayat' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('riwayat.pengajuan')); ?>">
              <i class="fas fa-fw fa-tachometer-alt"></i>
              <span>Riwayat</span></a>
          </li>
  
        <!-- Divider -->
        <hr class="sidebar-divider">
  
        <!-- Heading -->
        
  
        <!-- MAster -->
        <li class="nav-item <?php echo e(Request::path() === 'Administrator/kategori' ? 'active' : ''); ?>">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
            <i class="fas fa-fw fa-folder"></i>
            <span>Master Data</span>
          </a>
          <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="<?php echo e(route('kategori.index')); ?>">Data Kategori Surat</a>
              <a class="collapse-item" href="<?php echo e(route('admin.index')); ?>">Data Pegawai</a>
            </div>
          </div>
        </li>
        <!-- Rekap -->
        <li class="nav-item <?php echo e(Request::path() === 'Administrator/kategori' ? 'active' : ''); ?>">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2" aria-expanded="true" aria-controls="collapsePages">
            <i class="fas fa-fw fa-folder"></i>
            <span>Rekap </span>
          </a>
          <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="<?php echo e(route('rekap.tahun')); ?>">Rekap Tahun</a>
            
            </div>
          </div>
        </li>
        <?php endif; ?>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isKades')): ?>
          <!-- Nav Item - Dashboard -->
          <li class="nav-item <?php echo e(Request::path() === 'Administrator/home' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('home.index')); ?>">
              <i class="fas fa-fw fa-tachometer-alt"></i>
              <span>Dashboard</span></a>
          </li>
           <!-- Nav Item - Utilities Collapse Menu -->
        <li class="nav-item <?php echo e(Request::path() === 'Administrator/riwayat' ? 'active' : ''); ?>">
          <a class="nav-link" href="<?php echo e(route('riwayat.pengajuan')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Riwayat</span></a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isStaff')): ?>
          <!-- Nav Item - Dashboard -->
          <li class="nav-item <?php echo e(Request::path() === 'Administrator/home' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('home.index')); ?>">
              <i class="fas fa-fw fa-tachometer-alt"></i>
              <span>Dashboard</span></a>
          </li>
        <li class="nav-item <?php echo e(Request::path() === 'Administrator/riwayat' ? 'active' : ''); ?>">
          <a class="nav-link" href="<?php echo e(route('riwayat.pengajuan')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Riwayat</span></a>
        </li>
        <li class="nav-item <?php echo e(Request::path() === 'Administrator/kategori' ? 'active' : ''); ?>">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2" aria-expanded="true" aria-controls="collapsePages">
            <i class="fas fa-fw fa-folder"></i>
            <span>Rekap </span>
          </a>
          <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="<?php echo e(route('rekap.tahun')); ?>">Rekap Tahun</a>
             
            </div>
          </div>
        </li>
        <?php endif; ?>
       
        <li class="nav-item">
         
            <a class="nav-link collapsed" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                <i class="fas fa-fw fa-folder"></i>
                <span>Logout</span>
            </a>

            
           

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        
        </li>


        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">
  
         <!-- Sidebar Toggler (Sidebar) -->
         <div class="text-center d-none d-md-inline">
           <button class="rounded-circle border-0" id="sidebarToggle"></button>
         </div>
   
       </ul>
       <!-- End of Sidebar -->
            
        <?php elseif(auth()->guard('warga')): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('warga.home')); ?>">
            <i class="fas fa-fw fa-home"></i>
            <span>Home</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('warga.dashboard')); ?>">
            <i class="fas fa-fw fa-paper-plane"></i>
            <span>Pesan Surat</span></a>
        </li>

        
  
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('warga.riwayat')); ?>">
            <i class="fas fa-fw fa-history"></i>
            <span>Riwayat Pemesanan</span></a>
        </li>
  
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('warga.logout')); ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout</span></a>
        </li>
  
         <!-- Divider -->
         <hr class="sidebar-divider d-none d-md-block">
  
         <!-- Sidebar Toggler (Sidebar) -->
         <div class="text-center d-none d-md-inline">
           <button class="rounded-circle border-0" id="sidebarToggle"></button>
         </div>
   
       </ul>
       <!-- End of Sidebar -->
        <?php endif; ?>
      
  



     

        <?php /**PATH D:\TUGAS AKHIR\pengajuan-desa - rev\resources\views/layouts/include/sidebar.blade.php ENDPATH**/ ?>