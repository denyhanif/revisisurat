<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-1">
        <h1 class="h3 mb-0 text-gray-800">Formulir Permohonan Pindah</h1>
    </div>

    <div class="row">
        <div class="col-md-12 card shadow mb-4">
            <form class="mt-3 mb-2" action="<?php echo e(route('send.verifikasi')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>                    
                    <input hidden value="<?php echo e($data->pengajuan_id); ?>" name="id_pengaju" >
                    <input hidden value="<?php echo e($data->pesanan_id); ?>" name="id_pesanan" >
                    <input hidden value="<?php echo e($data->halaman); ?>" name="kat" >
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Pemesan Surat</label>
                        <input class="form-control" type="text" name="nama_pemesan" value="<?php echo e($data->nama_pemesan); ?>">
                    </div>    
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Daerah Asal</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">Nomor Kartu Keluarga</label>
                        <input class="form-control" type="text" name="no_kk" value="<?php echo e($data->no_kk); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Kepala Keluarga</label>
                        <input class="form-control" type="text" name="nama_kk" value="<?php echo e($data->nama_kk); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat</label>
                        <input class="form-control" type="text" name="alamat" value="<?php echo e($data->alamat); ?>">
                    </div>     
                    <div class="form-group col-md-8">
                        <label for="inputState">Desa / Kelurahan</label>
                        <input class="form-control" type="text" name="desa" value="<?php echo e($data->desa); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Kecamatan</label>
                        <input class="form-control" type="text" name="kecamatan" value="<?php echo e($data->kecamatan); ?>">
                    </div>    
                    <div class="form-group col-md-8">
                        <label for="inputState">Kab / Kota</label>
                        <input class="form-control" type="text" name="kab" value="<?php echo e($data->kab); ?>">
                    </div>         
                    <div class="form-group col-md-8">
                        <label for="inputState">Provinsi</label>
                        <input class="form-control" type="text" name="provinsi" value="<?php echo e($data->provinsi); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Kodepos</label>
                        <input class="form-control" type="text" name="kodepos" value="<?php echo e($data->kodepos); ?>">
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">NIK Pemohon</label>
                        <input class="form-control" type="text" name="nik_pemohon" value="<?php echo e($data->nik_pemohon); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Tempat Lahir</label>
                        <input class="form-control" type="text" name="tempat_lahir" value="<?php echo e($data->tempat_lahir); ?>">
                    </div>  
                    <div class="form-group col-md-8">
                        <label for="inputState">Tanggal Lahir</label>
                        <input class="form-control" type="text" name="tgl_lahir" value="<?php echo e($data->tgl_lahir); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Nama Lengkap</label>
                        <input class="form-control" type="text" name="nama" value="<?php echo e($data->nama); ?>">
                    </div>
                    <hr/>
                    <h1 class="h3 mb-0 text-gray-800">Data Kepindahan</h1>
                    <div class="form-group col-md-8">
                        <label for="inputState">Alasan Pindah</label>
                        <select name="alasan_pindah" class="form-control">
                            <option selected>-- Pilih --</option>
                            <option value="Pekerjaan">Pekerjaan</option>
                            <option value="Pendidikan">Pendidikan</option>
                            <option value="Keamanan">Keamanan</option>
                            <option value="Kesehatan">Kesehatan</option>
                            <option value="Perumahan">Perumahan</option>
                            <option value="Keluarga">Keluarga</option>
                            <option value="Lainnya">Lainnya</option>
                        </select>
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Alamat Tujuan Pindah</label>
                        <input class="form-control" type="text" name="tujuan_alamat_pindah" value="<?php echo e($data->tujuan_alamat_pindah); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Desa / Kelurahan</label>
                        <input class="form-control" type="text" name="tujuan_desa" value="<?php echo e($data->tujuan_desa); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Kecamatan</label>
                        <input class="form-control" type="text" name="tujuan_kecamatan" value="<?php echo e($data->tujuan_kecamatan); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Kab / Kota</label>
                        <input class="form-control" type="text" name="tujuan_kab" value="<?php echo e($data->tujuan_kab); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Provinsi</label>
                        <input class="form-control" type="text" name="tujuan_prov" value="<?php echo e($data->tujuan_prov); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Kodepos</label>
                        <input class="form-control" type="text" name="tujuan_kodepos" value="<?php echo e($data->tujuan_kodepos); ?>">
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Jenis Kepindahan</label>
                        <select name="jenis_pindah" class="form-control">
                            <option selected>-- Pilih --</option>
                            <option value="Kep. Keluarga">Kep. Keluarga</option>
                            <option value="Kep. Keluarga dan Seluruh Anggota Keluarga">Kep. Keluarga dan Seluruh Anggota Keluarga</option>
                            <option value="Kep. Keluarga Sebagai Anggota Keluarga">Kep. Keluarga Sebagai Anggota Keluarga</option>
                            <option value="Anggota Keluarga">Anggota Keluarga</option>
                        </select>
                    </div> 
                    <div class="form-group col-md-8">
                        <label for="inputState">Status KK bagi yang tidak pindah</label>
                        <select name="status_kk" class="form-control">
                            <option selected>-- Pilih --</option>
                            <option value="Numpang KK">Numpang KK</option>
                            <option value="Membuat KK Baru">Membuat KK Baru</option>
                            <option value="Nomor KK Tetap">Nomor KK Tetap</option>
                        </select>
                    </div>
                    <div class="form-group col-md-8">
                        <label for="inputState">Status KK bagi yang pindah</label>
                        <select name="status_no_kk_pindah" class="form-control">
                            <option selected>-- Pilih --</option>
                            <option value="Numpang KK">Numpang KK</option>
                            <option value="Membuat KK Baru">Membuat KK Baru</option>
                            <option value="Nomor KK Tetap">Nomor KK Tetap</option>
                        </select>
                    </div>
                    <div class="text-left mt-4 mb-4">
                        <button type="submit" class="btn btn-primary">Verifikasi</button>
                    </div>
            </form>
            <form class="mt-3 mb-2" action="<?php echo e(route('tolak')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input hidden value="<?php echo e($data->halaman); ?>" name="kat" >
                <input hidden value="<?php echo e($data->pesanan_id); ?>" name="idpesantolak" >
                <div class="text-left mb-4">
                    <button type="submit" class="btn btn-danger">Tolak</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frandito/Laravel/surat/resources/views/admin/dashboard/verifPermohonanPindah.blade.php ENDPATH**/ ?>