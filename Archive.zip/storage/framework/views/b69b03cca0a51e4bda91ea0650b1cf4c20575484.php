


<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Kategori Surat</h1>
    </div>

    <div class="row">
        <div class="col-md-12 card shadow mb-4">
            <form class="mt-3 mb-2" action="<?php echo e(route('kategori.update', $kategori->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group m-2">
                            <label class="mb-0" for="formGroupExampleInput">Alamat Instansi</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['alamat_instansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat_instansi" id="formGroupExampleInput" placeholder="Masukkan Alamat Instansi" value="<?php echo e($kategori->alamat_instansi); ?>">
                                <?php $__errorArgs = ['alamat_instansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput">Kode Surat</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['kode_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kode_surat" id="formGroupExampleInput" value="<?php echo e($kategori->kode_surat); ?>">
                                <?php $__errorArgs = ['kode_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput">Nama Kategori Surat</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_kategori" id="formGroupExampleInput" value="<?php echo e($kategori->nama); ?>">
                                <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group">
                            <label class="text-sm" for="formGroupExampleInput">Jabatan</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['jabatan_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jabatan_ttd" id="formGroupExampleInput"  value="<?php echo e($kategori->jabatan_ttd); ?>">
                                <?php $__errorArgs = ['jabatan_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="text-sm" for="formGroupExampleInput">Nama Pegaai</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_ttd" id="formGroupExampleInput"  value="<?php echo e($kategori->nama_ttd); ?>">
                                <?php $__errorArgs = ['nama_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="text-sm" for="formGroupExampleInput">NIP</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nomor_pegawai_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nomor_pegawai_ttd" id="formGroupExampleInput"  value="<?php echo e($kategori->nomor_pegawai_ttd); ?>">
                                <?php $__errorArgs = ['nomor_pegawai_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               
                        </div>

                        <div class="form-row p-0" >
                            
                                <div class="col-md-3 form-group m-1">

                                <label class="text-sm mb-0" for="formGroupExampleInput">Jarak Atas</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['margin_atas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="margin_atas" id="formGroupExampleInput" placeholder=" cm" value="<?php echo e($kategori->margin_atas); ?>">
                                    <?php $__errorArgs = ['margin_atas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-3 form-group m-1">
                                    <label class="text-sm mb-0" for="formGroupExampleInput"> Jarak Bawah</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['margin_bawah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="margin_bawah" id="formGroupExampleInput" placeholder=" cm" value="<?php echo e($kategori->margin_bawah); ?>">
                                        <?php $__errorArgs = ['margin_bawah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                  <div class="col-md-3 form-group m-1">
                                    <label class="text-sm mb-0" for="formGroupExampleInput">jarak kanan</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['margin_kekanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="margin_kekanan" id="formGroupExampleInput" placeholder="cm" value="<?php echo e($kategori->margin_kekanan); ?>">
                                        <?php $__errorArgs = ['margin_kekanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                           

                            
                            
                        </div>
                         <hr>
                        <div id="data-wrap">
                            <div id="input-wrap">
                                
                                <?php if(old('data')): ?>
                                    <?php $__currentLoopData = old('data')['nama']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group row input-wrapwrap">
                                        <div class="row col-auto" style="flex: 1 1 1px;">
                                            <div class="col-6">
                                                <label>Nama</label>
                                                <input type="text" class="form-control <?php echo e($errors->has('data.nama.'.$loop->index)  ? 'is-invalid' : ''); ?>" placeholder="Masukkan Nama" name="data[nama][]" value="<?php echo e(str_replace('_',' ',old('data')['nama'][$loop->index])); ?>">
                                                <?php $__errorArgs = ['data.nama.'.$loop->index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-6">
                                                <label>Tipe</label>
                                                <select class="form-control" name="data[type][]">
                                                    <option value="string" <?php echo e(old('data')['type'][$loop->index] == "string" ?  "selected" : ''); ?>>teks</option>
                                                    <option value="date" <?php echo e(old('data')['type'][$loop->index] == "date" ?  "selected" : ''); ?>>tanggal</option>
                                                    <option value="numeric" <?php echo e(old('data')['type'][$loop->index] == "numeric" ?  "selected" : ''); ?>>nomor</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <div class="form-gorup row">
                                                <label style="opacity: 0;">hapus</label>
                                                <button class="form-control btn btn-danger hapus">x</button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                <?php else: ?>
                                <?php $__currentLoopData = json_decode($kategori->data_template,true)['nama']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php
                                $data=json_decode($kategori->data_template,true);
                                    
                                ?>
                                <div class="form-group row input-wrapwrap">
                                        <div class="row col-auto" style="flex: 1 1 1px;">
                                            <div class="col-6">
                                                <label>Nama</label>
                                                <input type="text" class="form-control " placeholder="Masukkan Nama" name="data[nama][]" value="<?php echo e(str_replace('_',' ',$data['nama'][$loop->index])); ?>">
                                                <?php $__errorArgs = ['data.nama.'.$loop->index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-6">
                                                <label>Tipe</label>
                                                <select class="form-control" name="data[type][]">
                                                    <option value="string" <?php echo e($data['type'][$loop->index] == "string" ?  "selected" : ''); ?>>teks</option>
                                                    <option value="date" <?php echo e($data['type'][$loop->index] == "date" ?  "selected" : ''); ?>>tanggal</option>
                                                    <option value="numeric" <?php echo e($data['type'][$loop->index] == "numeric" ?  "selected" : ''); ?>>nomor</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <div class="form-gorup row">
                                                <label style="opacity: 0;">hapus</label>
                                                <button class="form-control btn btn-danger hapus">x</button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                <?php endif; ?>
                                
                            </div>
                        <div id="tambah">
                                <button class="btn btn-success" type="button"> tambah</button>
                        </div>

                        </div>
                        </div>
    
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Kop surat</label>
                            <textarea name="kop_surat" id="kop_surat" class="form-control <?php $__errorArgs = ['kop_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10"><?php echo e($kategori->kop_surat); ?></textarea>
                                <?php $__errorArgs = ['kop_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Isi Paragraf Awal</label>
                            <textarea name="paragraf_awal" id="paragraf_awal" class="form-control <?php $__errorArgs = ['paragraf_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10"><?php echo e($kategori->paragraf_awal); ?></textarea>
                                <?php $__errorArgs = ['paragraf_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Isi Paragraf Akhir</label>
                            <textarea name="paragraf_akhir" id="paragraf_akhir" class="form-control <?php $__errorArgs = ['paragraf_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10"><?php echo e($kategori->paragraf_akhir); ?></textarea>
                                <?php $__errorArgs = ['paragraf_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                </div>
                <div class="text-right">
                    <button class="btn btn-primary">Simpan</button>
                </div>
                
            </form>
        </div>
    </div>

    <script src="https://cdn.ckeditor.com/ckeditor5/21.0.0/classic/ckeditor.js"></script>

     
    <script>
            ClassicEditor
                    .create( document.querySelector( '#kop_surat' ) )
                    .then( editor => {
                     console.log( editor );
                        } )
                    .catch( error => {
                    console.error( error );
                    } );
    </script>
    <script>
            ClassicEditor
                    .create( document.querySelector( '#paragraf_awal' ) )
                    .then( editor => {
                     console.log( editor );
                        } )
                    .catch( error => {
                    console.error( error );
                    } );
    </script>
    <script>
            ClassicEditor
                    .create( document.querySelector( '#paragraf_akhir' ) )
                    .then( editor => {
                     console.log( editor );
                        } )
                    .catch( error => {
                    console.error( error );
                    } );
    </script>
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            let dataWrap= $("#input-wrap");
            $("#tambah button").click(function(){
                let a = $("<div>")
                    .addClass("form-group row input-wrapwrap ")
                    .append([
                        $("<div>").addClass("row col-auto").css("flex",1)
                            .append([
                                $("<div>")
                                    .addClass("col-6")
                                    .append([
                                        $("<label>").html("Nama"),
                                        $("<input>").attr({
                                            "type":"text",
                                            "class":"form-control",
                                            "placeholder":"Masukkan Nama",
                                            "name": "data[nama][]"
                                        })    
                                    ]), 
                                    $("<div>")
                                    .addClass("col-6")
                                    .append([
                                        $("<label>").html("Tipe"),
                                        $("<select>").attr({
                                            "class":"form-control",
                                            "name": "data[type][]"
                                        })
                                        .append([
                                            $("<option>").val("string").html("teks"),
                                            $("<option>").val("date").html("tanggal"),
                                            $("<option>").val("numeric").html("nomor"),
                                        ])
                                    ])
                                
                            ]),
                            $("<div>").addClass(" col-auto")
                            .append([
                                $("<div>")
                                    .addClass("form-gorup row")
                                    .append([
                                        $("<label>").html("hapus").css("opacity",0),
                                        $("<button>").attr({
                                            "class":"form-control btn btn-danger hapus",
                                        }).html("x")
                                    ])

                            ])
                    ])
                dataWrap.append(a);
            })
            
            $('#input-wrap').on('click','.hapus',function(){
                $(this).closest('.input-wrapwrap').remove()
            })
            
        });
    </script>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa\resources\views/admin/kategori/edit.blade.php ENDPATH**/ ?>