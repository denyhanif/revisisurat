
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Surat Keterangan lalal</title>
    
</head>

<body >
    
    <table border="" align="center " style="margin-top: -20px ;margin_left:30px;" >
    <tr>
        <td style="margin-top: 0">
            <center ><font align="center " size="4" style="font-weight: bold;margin-top: -20px;margin_right:40px"><?php echo $pengajuan->kategori->kop_surat; ?></font>
           
            <font size="3"><?php echo e($pengajuan->kategori->alamat_instansi); ?></font>
            </center>
        </td>
    </tr>
    <hr>
    </table>
<br>
<br>
<table align="center" border="" >
    <tr >
        <td align="center" ><b>Surat Pengantar <?php echo e($pengajuan->kategori->nama); ?></b><hr style="margin-top: 0" ></td>
    </tr>
    <tr align="center" style="margin-top: 0">
        <td><center>Nomer Surat <?php echo e($pengajuan->pesanan->nomer_surat); ?></center></td>
    </tr>
</table>
<br>
<table style="margin-bottom: <?php echo e($pengajuan->kategori->margin_atas); ?>cm;margin_left:30px;margin_right:30px" align="justify" border="">
    <tr>
        <td align="justify"><?php echo $pengajuan->kategori->paragraf_awal; ?></td>
    </tr>
</table>



<table style="margin-left: <?php echo e($pengajuan->kategori->margin_kekanan); ?>cm" align="justify" border="">
    <tr><td height=""></td></tr>
    <tr >
        <td>Dengan Ini Menerangkan Bahwa :</td>
    </tr>
    <tr>
        <td>Nama Lengkap</td>
        <td>: <?php echo e($pengajuan->nama_pemesan); ?></td>
    </tr>
    <?php $__currentLoopData = json_decode($pengajuan->data['nama'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item=>$q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="margin-left: 30px">
        <td><?php echo e(ucwords(str_replace('_',' ',$item))); ?></td>
        <td>: <?php echo e(ucwords($q)); ?></td>
        </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<table style="margin-bottom: <?php echo e($pengajuan->kategori->margin_bawah); ?>cm;margin_left:30px;margin_right:30px" align="justify" border="">
    <tr><td height=""></td></tr>
    <tr>
        <td align="justify" ><?php echo $pengajuan->kategori->paragraf_akhir; ?></td>
    </tr>
</table>

<table align="right" border="" style="margin_left:450px;margin_right:30px ">
    <tr><td height=""></td></tr>
    <tr style="">
        <td>Yogyakarta, <?php echo e(tgl_indo(Carbon\Carbon::parse(now())->format('Y-m-d'))); ?></td>
    </tr>
    <tr align="center">
        <td><?php echo e($pengajuan->kategori->jabatan_ttd); ?></td>
    </tr>
    <tr ><td height="50"></td></tr>
    <tr align="center">
        <td><b><?php echo e($pengajuan->kategori->nama_ttd); ?></b></td>
    </tr>
    <tr align="center">
        <td><b><?php echo e($pengajuan->kategori->nomor_pegawai_ttd); ?></b></td>
    </tr>
</table>
</body>
</html><?php /**PATH D:\TUGAS AKHIR\pengajuan-desa - rev\resources\views/surat.blade.php ENDPATH**/ ?>