<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_column_to_kategori extends Model
{
    //
}
