<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body{font-size: 11px;
            margin-left: 10px;
            margin-right: 10px;
        };
        .kop{margin-right: 10px};
        table.saksi{
            width: 50%;
        };
        td.header{
            border: solid 1px;
        }
        
    </style>
</head>
<body>
    
        {{--  <table class="align-center">
            <tr>
                <td> <img src="'public/img/kabupaten.jpg'" alt="" width="90" height="90"></td>

                <td align="center">
                   
                        <font size="4">DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL</font> <br>

                        <font size="2">Jalan KRT Pringgodani No.3 Beran, Tridadi, Sleman, DIY,55511</font> <br>

                        <font size="2">Telepon (0274) 868362, Faksimile (0274) 868945</font><br>
                        <font size="2">Website: www.slemankab.go.id ,Email:dukcapil@slemankab.go.id</font>
                   
                </td>
            </tr>
            <tr>
                <td colspan="2"><hr></td>
            </tr>
        </table>  --}}
     
        <table border="" align="center " style="margin-top: -20px ;margin_left:50px; margin-right:50px" >
            <tr style="padding-bottom: 0px">
                <td style="margin-right: 20px"> <img src="'public/img/kabupaten.jpg'" alt="" width="90" height="90">
                </td>
                <td style="margin-top: 0;margin-bottom:0px; margin-left:30px;padding-left:20px;padding-bottom:0px:">
                    <center>
                        <font  align="center " size="4" style="font-weight: bold"></font>
           
                        <font size="4">DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL</font> <br>

                        <font size="2">Jalan KRT Pringgodani No.3 Beran, Tridadi, Sleman, DIY,55511</font> <br>

                        <font size="2">Telepon (0274) 868362, Faksimile (0274) 868945</font><br>
                        <font size="2">Website: www.slemankab.go.id ,Email:dukcapil@slemankab.go.id</font>
                    </center>
                </td>
            </tr>
            <tr>
                <hr style="border: solid 1px;margin-top: 0;">
            </tr>
        
        </table>
{{--  tes  --}}
    <table>
            <tr>
                <td>
                    <ul style="list-style: none">
                        <li style="font-size: 12px" >PROVINSI</li>
                        <li>KABUPATEN</li>
                        <li>KECAMATAN</li>
                        <li>DESA</li>
                    </ul>
                </td> 
                <td class="header">
                    <ul style="list-style: none">
                        <li>30</li>
                        <li>04</li>
                        <li>12</li>
                        <li>200</li>
                    </ul>
                </td>
                 <td>
                    <ul style="list-style: none">
                        <li>DI YOGYAKARTA</li>
                        <li>SLEMAN</li>
                        <li>NGEMPLAK</li>
                        <LI>UMBULMARTANI</LI>
                    </ul>
                </td>
            </tr>
         </table>
    
        <table align="center">
            <tr>
                <td>
                    <center>
                        <b><font size="2">SURAT KETERANGAN PINDAH DATANG WNI</font> </b>    
                    </center>
                </td>
            </tr>
            <tr><td><center><b><font size="1">Antar Kecamatan Dalam Satu Kabupaten/Kota</font></b></center></td></tr>
            <tr><td><center><font size="1">No.</font></center></td></tr>
        </table>
    
    <table style="margin-top: 10px">
        <tr><font size="3"> DATA DAERAH ASAL</font></tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px">1.Nomor Kartu Keluarga</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px">2.Nama Kepala Keluarga</td>
            <td colspan="" id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px" >3.Alamat</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table style="margin-left: 150px">
        <tr>
            <td>RT/RW</td>
            <td>4/5</td>
        </tr>
    </table>
    <table style="margin-left: 150px">
        <tr>
            <td>Desa/Kelurahan</td>
            <td>:Hargobinangun</td>
            <td style="margin-left: 50px">Kabupaten</td>
            <td>:Sleman</td>
        </tr>
        <tr>
            <td>Kecamatan</td>
            <td>:Pakem</td>
            <td style="margin-left: 50px">Provinsi</td>
            <td>:D.I. YOGYAKARTA</td>
        </tr>
        
    </table>
    <table>
        <tr>
            <td style="width: 150px" >4.NIK Pemohon</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px" >5.Tempat/Tanggal lahir</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px" >6. Nama Lengkap Pemohon</td>
            <td id="data">:</td>
        </tr>
    </table>

    <table style="margin-top: 10px">
        <tr><font size="3"> DATA DAERAH TUJUAN</font></tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px">1.Status KK bagi yang pindah</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px">2.Nomor Kartu Keluarga</td>
            <td colspan="" id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px" >3.NIK pemohon</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px" >4.Nama Kepala Keluarga</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px" >5.Tanggal Kedatangan</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table>
        <tr>
            <td style="width: 150px" >6. Alamat yang Dituju</td>
            <td id="data">:</td>
        </tr>
    </table>
    <table style="margin-left: 150px">
        <tr>
            <td>RT/RW</td>
            <td>4/5</td>
        </tr>
    </table>
    <table style="margin-left: 150px">
        <tr>
            <td>Desa/Kelurahan</td>
            <td>:Hargobinangun</td>
            <td style="margin-left: 100px">Kabupaten</td>
            <td>:Sleman</td>
        </tr>
        <tr>
            <td>Kecamatan</td>
            <td>:Pakem</td>
            <td style="margin-left: 100px">Provinsi</td>
            <td>:D.I. YOGYAKARTA</td>
        </tr>
          <tr>
            <td>Kode pos</td>
            <td>:Pakem</td>
            <td style="margin-left: 100px">Telepon</td>
            <td>:D.I. YOGYAKARTA</td>
        </tr>
        
    </table>
     <table>
        <tr>
            <td style="width: 150px" >7. Keluarga yang Datang</td>
            <td id="data">:</td>
        </tr>
    </table>
     <table align="left" border="" style=" margin-top:0px;padding-top:0px; ">
    <tr><td height=""></td></tr>
    <tr style="">
        <td> Menegtahui</td>
    </tr>
    <tr style="">
        <td>a.n KEPALA DESA UMBULMARTANI</td>
    </tr>
    <tr ><td height="50"></td></tr>
    <tr align="center">
        <td><b>sUGIO</b></td>
    </tr>
   <table align="right" border="" style="margin_left:500px ">
    <tr><td height=""></td></tr>
    <tr style="">
        <td>Umbulmartani, 20/Desember/2020 </td>
    </tr>
    <tr align="center">
        <td>pelapor</td>
    </tr>
    <tr ><td height="50"></td></tr>
    <tr align="center">
        <td><b>Rahmat edi</b></td>
    </tr>

</table>
    
   
</body>
</html>