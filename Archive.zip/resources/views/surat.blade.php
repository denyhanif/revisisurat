{{-- {{--  <!DOCTYPE html> --}}
<html lang="en">
<head>
    <title>Surat Keterangan Kelahiran</title>
</head>
<table style="font-size:11px; margin-top: 10px; border: 1px solid black;">
    <tr>
        <td style="margin-top: 0">
           <b>KODE . F-2.01</b> 
        </td>
</table>
<table border="" width="50%" style="font-size:11px; margin-top: 10px">
    <tr>
        <td style="margin-top: 0">
           Pemerintah Desa/Kelurahan 
        </td>
        <td style="margin-top: 0">
            <b>: UMBULMARTANI</b>
         </td>
    </tr>
    <tr>
        <td style="margin-top: 0">
           Kecamatan
        </td>
        <td style="margin-top: 0">
            <b>: NGEMPLAK</b>
         </td>
    </tr>
    <tr>
        <td style="margin-top: 0">
           Kabupaten
        </td>
        <td style="margin-top: 0">
            <b>: SLEMAN</b>
         </td>
    </tr>
</table>

<br>
<br>
<table align="center" style="" border="">
    <tr>
        <td align="center"><b>SURAT KETERANGAN KELAHIRAN</b><hr></td>
    </tr>
    <tr>
        <td><center>Nomer Surat  {{ $pengajuan->nomer_surat }}</center></td>
    </tr>
</table>
<br>
<table style="margin-left: 1.5cm; font-size:11px;" border="">
    <tr>
        <td>1. Nomor Kartu Keluarga</td>
        <td>: {{ $pengajuan->no_kk }}</td>
    </tr>
    <tr>
        <td>2. Nama Kepala Kartu Keluarga</td>
        <td>: {{ $pengajuan->nama_kk }}</td>
    </tr>
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
<tr>
    <td>
        <b>BAYI/ANAK</b>
    </td>
</tr>
<tr>
    <td>
        <table style="margin-left: 1.5cm;">
            <tr>
                <td>1. NIK</td>
                <td>: </td>
            </tr>
            <tr>
                <td>2. Nama</td>
                <td>: {{ $pengajuan->nama }}</td>
            </tr>
            <tr>
                <td>3. Jenis Kelamin</td>
                <td>: </td>
            </tr>
            <tr>
                <td>4. Tempat Kelahiran</td>
                <td>: </td>
            </tr>
            <tr>
                <td>5. Tempat Lahir</td>
                <td>: </td>
            </tr>
        </table>
    </td>
</tr> 
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
    <tr>
        <td>
            <b>IBU</b>
        </td>
    </tr>
    <tr>
        <td>
            <table style="margin-left: 1.5cm;">
                <tr>
                    <td>1. NIK</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>2. Nama</td>
                    <td>: {{ $pengajuan->nama }}</td>
                </tr>
                <tr>
                    <td>3. Jenis Kelamin</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>4. Tempat Kelahiran</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>5. Tempat Lahir</td>
                    <td>: </td>
                </tr>
            </table>
        </td>
    </tr> 
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
    <tr>
        <td>
            <b>AYAH</b>
        </td>
    </tr>
    <tr>
        <td>
            <table style="margin-left: 1.5cm;">
                <tr>
                    <td>1. NIK</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>2. Nama</td>
                    <td>: {{ $pengajuan->nama }}</td>
                </tr>
                <tr>
                    <td>3. Jenis Kelamin</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>4. Tempat Kelahiran</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>5. Tempat Lahir</td>
                    <td>: </td>
                </tr>
            </table>
        </td>
    </tr> 
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
    <tr>
        <td>
            <b>PELAPOR</b>
        </td>
    </tr>
    <tr>
        <td>
            <table style="margin-left: 1.5cm;">
                <tr>
                    <td>1. NIK</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>2. Nama</td>
                    <td>: {{ $pengajuan->nama }}</td>
                </tr>
                <tr>
                    <td>3. Jenis Kelamin</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>4. Tempat Kelahiran</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>5. Tempat Lahir</td>
                    <td>: </td>
                </tr>
            </table>
        </td>
    </tr> 
</table>
<table width="100%" style="font-size:11px; border: 1px solid black;">
    <tr>
        <td>
            <b>SAKSI</b>
        </td>
    </tr>
    <tr>
        <td>
            <table style="margin-left: 1.5cm;">
                <tr>
                    <td>1. NIK</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>2. Nama</td>
                    <td>: {{ $pengajuan->nama }}</td>
                </tr>
                <tr>
                    <td>3. Jenis Kelamin</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>4. Tempat Kelahiran</td>
                    <td>: </td>
                </tr>
                <tr>
                    <td>5. Tempat Lahir</td>
                    <td>: </td>
                </tr>
            </table>
        </td>
    </tr> 
    </table>
    <table style="margin-left: 1.5cm;">
        <tr>
            <td>NIK</td>
            <td>Nama</td>
            <td>Masa Berlaku</td>
            <td>SHDK</td>
        </tr>
        @foreach ($data_kel as $data)
        <tr>
            <td>{{ $data->nik }}</td>
            <td>{{ $data->nama }}</td>
            <td>{{ $data->masa_berlaku }}</td>
            <td>{{ $data->shdk }}</td>
        </tr>
        @endforeach
    </table>

<table  style="margin-top: {{ $kategori->margin_bawah }}cm" align="left" border="">
    <tr><td height="100"></td></tr>
    <tr>
        <td>{!! $kategori->paragraf_akhir !!}</td>
    </tr>
</table>

<table align="right" border="">
    <tr><td height="70"></td></tr>
    <tr>
        <td>Yogyakarta, {{ tgl_indo(Carbon\Carbon::parse(now())->format('Y-m-d')) }}</td>
    </tr>
    <tr>
        <td>{{ $kategori->jabatan_ttd }}</td>
    </tr>
    <tr><td height="50"></td></tr>
    <tr>
        <td><b>{{ $kategori->nama_ttd }}</b></td>
    </tr>
    <tr>
        <td><b>{{ $kategori->nomor_pegawai_ttd }}</b></td>
    </tr>
</table>
<body>
    
</body>
</html>
{{-- <!DOCTYPE html>
<html lang="en">
<head>
    <title>Surat Keterangan lalal</title>
    
</head>

<body >
    
    <table border="" align="center " style="margin-top: -20px ;margin_left:30px;" >
    <tr>
        <td style="margin-top: 0">
            <center ><font align="center " size="4" style="font-weight: bold;margin-top: -20px;margin_right:40px">{!! $pengajuan->kategori->kop_surat !!}</font>
           
            <font size="3">{{ $pengajuan->kategori->alamat_instansi }}</font>
            </center>
        </td>
    </tr>
    <hr>
    </table>
<br>
<br>
<table align="center" border="" >
    <tr >
        <td align="center" ><b>Surat Pengantar {{ $pengajuan->kategori->nama }}</b><hr style="margin-top: 0" ></td>
    </tr>
    <tr align="center" style="margin-top: 0">
        <td><center>Nomer Surat {{ $pengajuan->pesanan->nomer_surat }}</center></td>
    </tr>
</table>
<br>
<table style="margin-bottom: {{ $pengajuan->kategori->margin_atas }}cm;margin_left:30px;margin_right:30px" align="justify" border="">
    <tr>
        <td align="justify">{!! $pengajuan->kategori->paragraf_awal !!}</td>
    </tr>
</table>



<table style="margin-left: {{ $pengajuan->kategori->margin_kekanan }}cm" align="justify" border="">
    <tr><td height=""></td></tr>
    <tr >
        <td>Dengan Ini Menerangkan Bahwa :</td>
    </tr>
    <tr>
        <td>Nama Lengkap</td>
        <td>: {{ $pengajuan->nama_pemesan }}</td>
    </tr>
    @foreach (json_decode($pengajuan->data['nama'],true) as $item=>$q)
        <tr style="margin-left: 30px">
        <td>{{ ucwords(str_replace('_',' ',$item)) }}</td>
        <td>: {{ ucwords($q) }}</td>
        </tr>
        
    @endforeach

</table>

<table style="margin-bottom: {{ $pengajuan->kategori->margin_bawah }}cm;margin_left:30px;margin_right:30px" align="justify" border="">
    <tr><td height=""></td></tr>
    <tr>
        <td align="justify" >{!! $pengajuan->kategori->paragraf_akhir !!}</td>
    </tr>
</table>

<table align="right" border="" style="margin_left:450px;margin_right:30px ">
    <tr><td height=""></td></tr>
    <tr style="">
        <td>Yogyakarta, {{ tgl_indo(Carbon\Carbon::parse(now())->format('Y-m-d')) }}</td>
    </tr>
    <tr align="center">
        <td>{{ $pengajuan->kategori->jabatan_ttd }}</td>
    </tr>
    <tr ><td height="50"></td></tr>
    <tr align="center">
        <td><b>{{ $pengajuan->kategori->nama_ttd }}</b></td>
    </tr>
    <tr align="center">
        <td><b>{{ $pengajuan->kategori->nomor_pegawai_ttd }}</b></td>
    </tr>
</table>
</body>
</html> --}}